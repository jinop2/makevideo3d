# Grammaire visuelle

Repères en pixels pour un canevas 1080x1920 (9:16). Les valeurs viennent de mesures sur les vidéos de référence quand elles sont indiquées.

## 1. Choisir la famille selon le thème (le décor varie, la grammaire reste)
| | `fantasy` | `city` | `neon` | `toon` (2D adapté en 3D) |
|---|---|---|---|---|
| Référence | vidéos 4, 5, 6 | « payé quand on a pas de chance » | vidéos 1, 2, 3 | `Sequence_04` |
| Thème type | monde extrême, tours géantes, lore, séries | histoire du quotidien, humour, argent, chance | satire sociale, soirée, vote | idées simples en 35-45 s, échelle sociale, CTA |
| Rendu | blocs, ciel pastel, grande échelle | blocs, rue de ville lumineuse et réaliste | flat néon saturé | contours épais, aplats, chibi |
| Sous-titres | jaune acide, contour noir | idem (plus petits) | mots 3D colorés (approché) | **dorés en capitales** (`captionPreset: gold`) |
| HUD | badge PARTIE + jauge ÉTAGE | pastille d'argent, téléphone, compteurs | cartes de commentaires | compteur d'étage **empilé** (`gaugeStyle: stack`) |
| Plan moyen | 1,4 à 2,4 s | **~1,4 s** | 3,5 à 4,7 s + caméra continue | 2 à 3,5 s (une carte par idée) |
| Réglages moteur | `sky: sunset`, décors `slum skyline giantTower cloudDeck palace controlRoom waterTown nightGrid` | `sky: day`, décors `avenue facade bedroom street poolDeck` | `sky: neon` | `toon: true`, `sky: flatday`, personnage `style: chibi`, décors `flatCity cutaway island luxRoom burst` |

Règles :
- **Une seule famille par vidéo.** Choisir selon le thème de l'histoire (pas par habitude).
- **Le décor change à chaque idée** (comme dans la référence 2D : sol -> étages -> espace -> île -> salon), il n'est pas figé sur un seul lieu.
- On peut **mélanger** `toon: false` sur un plan précis (`"toon": false`) pour un effet de contraste, rarement.

### Adapter un décor 2D en 3D (famille `toon`)
Principe : garder **la composition, les couleurs et les silhouettes** de l'illustration 2D, mais construire en volume peu profond.
1. **Caméra quasi frontale à faible champ** : `fov` 24 à 34 et caméra loin (12 à 26 m) donnent l'aplat « 2.5D ». Largeur visible ≈ `2 x distance x tan(fov/2) x 0,5625` (ex. 14 m et fov 30 : ~4,2 m) : placer héros et accessoire principal dans cette largeur.
2. **Contours** : `config.toon: true` (matières à aplats + contour noir). `outline` (défaut 0,04) pour l'épaisseur.
3. **Un décor = une idée** : sol brun + cabane + tours colorées = « pauvre » ; `cutaway` = étage n ; `island` = milliardaires ; `luxRoom` = luxe ; `burst` = appel à l'action.
4. **Compteurs en 2D par-dessus** : `hud.style: stack`, `hud.floor` ou `hud.label`.
5. **Pas d'ombres** (`"shadows": false`) : l'illustration 2D est à plat.
6. Personnage `style: chibi` (grosse tête, joues, capuche `hoodie`) dans `cast.json`.

### Format court (35 à 45 s)
Une idée, 4 à 6 décors, 12 à 20 plans, un seul rebondissement et un appel à l'action de 6 à 8 s (commentaire ou question). Voir `narrative-formula.md`, section 8.

## 2. Types de plans (alterner, jamais plus de 3 du même type d'affilée)
1. **Plan d'établissement géant** : la ville entière, la tour, le ciel. Caméra en contre-plongée ou plongée verticale. Sert à chaque nouveau lieu.
2. **Plan héros moyen** : personnage centré, 40-60 % de la hauteur, lieu lisible derrière.
3. **Gros plan visage** : yeux ronds, bouche en O, sourcil. Plein cadre, pour la surprise/l'effroi.
4. **Insert objet** : clé, écran, panneau, pièce, main. Remplit l'écran, 0,8 à 1,5 s.
5. **Plan foule** : de nombreux petits personnages, un seul qui réagit (point d'exclamation au-dessus).
6. **POV mouvement** : glissade, ascenseur, chute, tyrolienne. Lignes de vitesse, caméra qui tourne.
7. **Écran dans l'écran** : écran/hologramme/commentaire qui affiche une info (SCANNING, NOUVEAU PROPRIÉTAIRE, chiffre).
8. **Contraste d'ambiance** : bascule jour pastel -> nuit noire avec grille néon pour le danger.

## 3. Caméra
- Chaque plan a un mouvement (poussée lente, orbite, travelling, plongée) : pas de plan fixe.
- Verticalité : utiliser contre-plongées sur les tours, plongées sur les foules/cabanes.
- Zoom rapide ou whip (0,2 s) sur les mots-clés et les révélations.
- Mouvements de caméra qui accompagnent le sens (monter = riches/progrès, descendre = chute/pauvres).

## 4. Rythme de coupe
- `fantasy`/`city` : médiane 1,4 à 2,4 s. Phrases d'action : 0,8 à 1,5 s. Révélations et visages : 2 à 4 s. Jamais plus de ~6 s sans changement.
- `neon` : 3,5 à 4,7 s mais caméra en mouvement continu ; transitions glitch/liquide/bande de film.
- Couper 0,1 à 0,2 s avant le mot qu'on illustre.
- ~ 25 à 45 plans par minute en `fantasy`/`city`, ~ 13 à 17 en `neon`, ~ 17 à 30 en `toon`.

## 5. Sous-titres mot par mot

### `fantasy` et `city` (jaune acide)
- Un seul mot visible à la fois, centré horizontalement (x ≈ 49 % mesuré), **verticalement vers 61-66 % de la hauteur** (y ≈ 1170-1275 px).
- Police : sans-serif géométrique très grasse (Montserrat Black/ExtraBold ou équivalente), minuscules.
- Remplissage jaune acide **#E3FC2B** (mesuré), contour noir 10-14 px, ombre portée légère.
- Taille de base : corps ~98 px (lettre courante ~72 px de haut, mesuré). Mot-clé : x1,45 (jusqu'à ~106 px de haut), ou couleur alternative (cyan `#6EE7FF`, blanc, rouge) ; nombres géants dorés.
- Apparition instantanée (pop 2-3 images), sans fondu. Changement de mot = nouveau mot en ≤ 0,4 s.
- Tenir hors de la zone des interfaces TikTok : bas ≥ 380 px et latéraux ≥ 120 px libres pour les boutons.
- Les mots de liaison (« et », « le », « de ») peuvent être plus petits.

### `toon` (doré)
- Capitales dorées (dégradé jaune `#ffe566` -> orange `#ff9d1a`), contour brun `#3a1800`, ombre douce, corps ~70 px, mot-clé x1,45 plus clair. Réglage : `captionPreset: "gold"`, position `captionStyle.capY` (0,5 par défaut) ou `capY` dans le plan.
- Compteur d'étage empilé : gros chiffre blanc + « ÉTAGE » doré (`gaugeStyle: "stack"`).

### `neon`
- Mots 3D dans la scène : mêmes mots, mais rendus comme du texte en volume avec contour sombre, une couleur par mot (bleu, vert, orange, rouge, blanc), placés au centre de l'écran et parfois en perspective.
- Les mots peuvent ondoyer ou se déformer lors des transitions liquides.

## 6. HUD et accessoires d'interface (`fantasy`)
- **Badge PARTIE N** : coin haut-gauche (x ≈ 20-60 px, y ≈ 70-90 px), rectangle arrondi sombre, liseré jaune, texte jaune acide en capitales, petit.
- **Jauge ÉTAGE** : barre verticale fine sur le bord gauche, encadré avec « ÉTAGE n ». Le chiffre suit l'altitude et doit être cohérent avec la voix off (« 100 étages » -> 100 à l'écran).
- **Écrans diégétiques** : « SCANNING.. » + barre, bandeau « NOUVEAU PROPRIÉTAIRE IDENTIFIÉ », panneau « DANGER ».
- **Étiquettes 3D de lieu** : texte en capitales flottant au-dessus du décor (ex. nom de quartier).
- **Point d'exclamation** jaune au-dessus d'un personnage qui remarque quelque chose.
- Nombres flottants (+14, 200) qui apparaissent en pop et disparaissent en 0,6 s.

## 7. Couleur
- **Code riche/pauvre constant** dans une même histoire : pauvre = bruns, bois, tôle, vêtements rapiécés, herbe terne ; riche = verre, or, blanc/lavande, piscines turquoise, nuages roses.
- **Ciel** : dégradé coucher de soleil (rose -> violet -> orange) pour les moments émotionnels, bleu jour pour l'établissement, nuit noire + néon pour le danger.
- **Alerte** : rouge (yeux, alarme) sur fond sombre, jamais en grand aplat sur fond clair.
- **Une couleur signature par personnage**, qui ne bouge jamais (ex. héros bleu-gris rapiécé, antagoniste blanc et or).
- Néon : magenta `#E11EA4`, violet `#5212AB`, orange `#D96B0D`, damier lavande `#EDDDFF`, turquoise piscine.

## 8. Transitions
- `fantasy`/`city` : coupes sèches, zoom-through, whip, flash blanc court sur les gros événements, passage par l'obscurité pour entrer dans un lieu interdit.
- `neon` : glitch, ondulation liquide, bande de film noir et blanc pour flashback, dézoom sur écran.

## 9. Écrans de fin
Fond dégradé plein cadre (bleu nuit, ou rose -> violet) sans décor, durée 2 à 3 s, voix off finie.
- Titre : « PARTIE 2 BIENTÔT » ou « FIN », gros, blanc, contour noir épais, légère rotation (-3°).
- Sous-titre : question courte en jaune acide, ≤ 8 mots.
- Si la voix off finit sur un cliffhanger, le dernier plan est un gros plan figé (visage ou objet) avant la carte.

## 10. Checklist QC (sur une planche-contact 1 image / 3 s)
- [ ] Le hook (0-3 s) montre le contraste/la règle, avec un mot-clé gros.
- [ ] Chaque plan correspond aux mots dits. Les chiffres à l'écran = chiffres dits.
- [ ] Sous-titres lisibles sur téléphone, un mot à la fois, hors zones d'interface.
- [ ] Mouvement de caméra dans chaque plan.
- [ ] Pas plus de 3 plans du même type d'affilée.
- [ ] Code riche/pauvre cohérent, héros reconnaissable à chaque plan.
- [ ] Badge PARTIE et jauge présents (famille `fantasy`) et cohérents.
- [ ] Écran de fin avec question ≤ 8 mots.
- [ ] Voix claire, musique sous la voix, pas d'accumulation de SFX, loudness ~ -14 à -16 LUFS.
