# Formule narrative et écriture de la voix off

## 1. Les 6 temps d'une partie (80 à 110 s)
Repères de minutage pour ~90 s. Ce sont des proportions observées, pas des lois : adapter à la durée réelle.

| Temps | Durée | Fonction | Contenu |
|---|---|---|---|
| 1. Hook | 0 à 4 s | Arrêter le scroll | Le principe choc du monde en une phrase : un contraste extrême ou une règle absurde. Mot-clé fort dès le 1er ou 2e mot. |
| 2. Règles du monde | 4 à 18 s | Rendre le monde lisible | Échelle verticale/spatiale, qui est en haut, qui est en bas, ce qui est interdit. Chiffres qui montent. |
| 3. Le héros et l'enjeu | 18 à 35 s | Attachement | Je (narrateur) + un quotidien concret et injuste (détail précis : échelle cassée, baskets trouées) + un proche (ami, frère). |
| 4. Déclencheur | 35 à 55 s | Basculer | Événement qui casse l'ordre : tremblement, objet tombé, scan, appel, panne. |
| 5. Escalade et révélation | 55 à 85 s | Récompense | Accès au secret, antagoniste, machine, retournement qui change le sens du monde. |
| 6. Crochet de fin | 85 à 100 s | Provoquer la suite | Question, twist ou double inattendu, puis écran de fin. |

Une **partie 2** commence par un rappel express (1 à 2 phrases) puis enchaîne sur la suite directe. Ne jamais refaire toute l'exposition.

## 2. Écrire la voix off
- **Première personne** (« je »). Alterner présent et passé composé comme dans une confidence orale.
- **Phrases courtes** : 5 à 12 mots. Une idée par phrase. Pas de subordonnées longues.
- **Débit cible** : 2,5 à 3 mots par seconde. 90 s ≈ 230 à 270 mots. Compter avant de valider.
- **Chiffres et superlatifs** : « 100 étages », « si hautes qu'elles touchent l'espace ». Une montée de chiffres par partie.
- **Détail concret avant l'explication** : montrer par un objet précis (échelle cassée, baskets trouées) avant le concept.
- **Règle explicite** (au moins une) : ce qui est interdit, ce qui se passe si on désobéit.
- **Question implicite** toutes les 15 à 20 s (« mais pourquoi... ? », « qui... ? ») pour garder la tension.
- **Mots-clés visuels** : chaque phrase contient 1 mot qui peut être mis en gros dans les sous-titres (lieu, chiffre, personnage, objet).
- **Pas de morale, pas de conclusion** : on s'arrête sur le crochet.
- **Langue** : français parlé, naturel, sans jargon. Pas de phrases écrites « livresques ».

## 3. Hooks qui marchent (modèles de construction)
- **Inversion d'échelle** : « Dans cette ville, plus tu es riche, plus ta maison est haute. »
- **Règle interdite** : « Ici, il est interdit de toucher l'eau. »
- **Chiffre choquant** : « Ma maison est au 1er étage, celle de mon meilleur ami au 300e. »
- **Secret révélé** : « Personne n'a le droit de monter. J'ai tout de même trouvé l'ascenseur. »
Ne pas recopier ces phrases telles quelles dans une vraie vidéo : en inventer d'autres du même moule.

## 4. Fins et mécanique des commentaires
Choisir une fin par partie :
1. **Cliffhanger + PARTIE N+1 BIENTÔT** : question en sous-titre (« Qui a ... ? »).
2. **FIN + sondage** : « Tu veux une partie 3 ? ».
3. **Vote diégétique** (famille néon) : un cadre commentaire « ? » apparaît, le mot « choisis » / « décide » est dit, deux options claires (par ex. piscine ou escalier). Le commentaire le plus liké devient la suite. Prévoir dans la partie suivante un plan qui montre le commentaire gagnant.
4. **Miroir** : le héros se voit ou voit quelqu'un qui lui ressemble (twist d'identité).

La question de fin doit être **courte (≤ 8 mots)** et répondre par oui/non ou par un nom.

## 5. Fiche de série (`story/bible.md`)
```
Titre de série :
Logline (1 phrase) :
Monde : règle choc / échelle / code couleur (pauvre = ..., riche = ...)
Héros : id, nom, âge perçu, tenue (1 couleur signature), défaut visible, objectif
Alliés : ...
Antagoniste : ... (silhouette reconnaissable : chapeau, couleur, accessoire)
Lieux (3 à 6) : nom, ambiance (jour pastel / coucher de soleil / nuit néon / horreur), 3 éléments signature
Objets récurrents : clé, écran, jauge, panneau
HUD : badge PARTIE N, jauge (ÉTAGE / NIVEAU / PROFONDEUR), autres compteurs
Palette : 3 couleurs dominantes + 1 couleur d'alerte
Musique : sections et intensités (voir audio-and-timing.md)
Partie 1 : crochet de fin / Partie 2 : ... / Partie 3 : ...
```

## 6. Idées de mondes (pour le cas B : créer l'histoire)
Proposer 3 pitchs à chaque demande, dans ce moule : **un monde organisé par un critère absurde + un héros du mauvais côté + un secret**.
- Ville où le rang social = l'altitude (déjà utilisé, à varier : altitude -> profondeur sous terre).
- Ville inondée où seul le toit du quartier de sa couleur est sûr.
- École où la note détermine l'étage et la durée de vie du badge.
- Île où chaque habitant a un compteur de temps au-dessus de la tête et le temps se vole.
- Immeuble où chaque étage vit à une saison différente.
Chaque pitch : monde, règle choc, héros, secret, cliffhanger de la partie 1.

## 7. Format d'export du texte de voix off (à envoyer à l'utilisateur pour l'enregistrement)
Livrer un bloc de texte propre, **exactement ce qui sera enregistré**, sans rien d'autre dedans :
- Pas de didascalies, pas d'indications de ton entre parenthèses, pas d'émojis, pas de numéros de plan, pas de titres dans le bloc.
- Une phrase par ligne (la ponctuation règle les pauses : virgule = souffle court, point = pause nette). Éviter les points de suspension et les tirets longs.
- Nombres : en chiffres uniquement si la voix choisie les lit correctement (vérifier à l'écoute), sinon en lettres. Les sous-titres affichent les mots tels qu'ils sont écrits.
- Noms propres inventés : simples à prononcer, orthographe stable, les répéter à l'identique.
- Donner en dessous (hors du bloc) : nombre de mots, durée estimée (mots / 2,7 s), et la ligne de fin (question de l'écran de fin).
- Ce texte devient `input/script.txt` : le conserver tel quel, il sert à aligner les sous-titres sur l'audio.
- Si l'utilisateur modifie le texte à l'enregistrement, lui demander le texte réellement dit.

Exemple de livraison :
```
[texte de la voix off, une phrase par ligne]

Mots : 235 · Durée estimée : ~87 s · Écran de fin : « PARTIE 2 BIENTÔT » + « Qui a pris la clé ? »
```

## 8. Format court : 35 à 45 s (~105 à 125 mots)
La référence 2D dure 39,6 s : une idée suffit, pas besoin de 60 s. Proportions pour 40 s :
| Temps | Durée | Contenu |
|---|---|---|
| Hook | 0 à 3 s | idée choc / contraste (« plus c'est haut, plus c'est riche ») |
| Monde par étapes | 3 à 20 s | 3 ou 4 « marches » qui montent (étage 2, 10, 42, 131, 330...) chacune dans un décor différent |
| Pointe | 20 à 30 s | le sommet : les plus riches, la chute (le héros « moi » tout en bas) |
| Appel à l'action | 30 à 40 s | question ou demande de commentaire, bouton abonnement, écran de fin |
Mots : 2,7 mots/s x durée. Coupe : une carte par phrase (2 à 3,5 s).

## 9. Motifs d'idées vus dans les références (à réinventer, jamais à recopier)
- **Échelle verticale** : étages qui montent, chaque palier plus absurde que le précédent.
- **Inversion de règle** : la règle du monde est l'inverse de l'attendu (la malchance enrichit). On l'annonce dans la première phrase puis on la prouve par une série de petits gags.
- **Système caché** : une institution/écran qui scanne le héros et le déclare spécial (« analyse en cours... »).
- **Révélation par téléphone** : un message plein écran dévoile ligne par ligne la vérité (félicitations, statut, montant).
- **Prénom du héros tôt** (l'identification) puis répété dans la révélation.
- **Appel aux commentaires** : une question simple à laquelle on répond en un mot (un prénom, un choix, oui/non), parfois avec un compteur d'abonnés/argent.
