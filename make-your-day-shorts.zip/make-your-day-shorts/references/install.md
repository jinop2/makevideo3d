# Installation du kit (une fois par machine)

Le dossier `kit/` du skill est un petit studio Node + Python : Three.js dessine le monde, Chromium headless capture chaque image, ffmpeg encode, Python fait la transcription et le son. Le skill est en lecture seule : **copier `kit/` dans un dossier de travail** (celui du projet de l'utilisateur, ou le dossier courant) sous le nom `studio/`.

## 1. Copier
```
cp -r <skill>/kit/. studio/          (bash)
Copy-Item -Recurse "<skill>\kit\*" studio\    (PowerShell)
```
Si `studio/render.mjs` existe déjà, le kit est installé : ne rien écraser, surtout pas `studio/projects/`.

## 2. Dépendances (dire à l'utilisateur en une courte liste ce qui s'installe)
| Besoin | Windows | macOS | Linux |
|---|---|---|---|
| ffmpeg + ffprobe | `winget install Gyan.FFmpeg` | `brew install ffmpeg` | `sudo apt install ffmpeg` |
| Node.js 18+ | `winget install OpenJS.NodeJS.LTS` | `brew install node` | paquet de la distribution |
| Python 3.9+ | python.org | `brew install python` | distribution |
| Paquets JS (three, playwright, police) | `npm install` dans `studio/` | idem | idem |
| Chromium pour Playwright | `npx playwright install chromium` | idem | idem (+ `npx playwright install-deps chromium` si des bibliothèques manquent) |
| Paquets Python | `python -m pip install numpy scipy faster-whisper` | idem | idem + `--break-system-packages` si nécessaire |

Puis : `python tools/doctor.py` (ajouter `--install` pour lancer les installations automatiquement). Toutes les lignes doivent être « OK ».

Si un Chromium/Chrome est déjà installé : `CHROMIUM_PATH=/chemin/vers/chrome` (variable d'environnement) évite le téléchargement de Playwright.

## 3. Test de bout en bout (2 minutes)
```
node render.mjs --project examples/demo --sheet --scale 0.35
```
Doit écrire `examples/demo/build/sheets/sheet_01.png` (11 plans : tours, bidonville, palais, gros plans, écran de fin) sans message d'erreur. Même test pour le style 2D adapté en 3D : `node render.mjs --project examples/demo-toon --sheet --scale 0.35` (6 plans : cabane, étages, île, salon, avenue, appel à l'action). Ouvrir l'image pour vérifier, puis supprimer `examples/demo/build/`.

## 4. Vitesse (mesurée) et conseils
- Mesure faite dans un conteneur à **1 CPU sans GPU** (rendu logiciel SwiftShader) : ~3,7 images/s à 30 % de la résolution (324x576). La pleine résolution (1080x1920) est ~11 fois plus lourde : prévoir **plusieurs heures** pour 90 s sans GPU.
- Avec un GPU : `--gl gpu` accélère fortement. Sur Windows/macOS le mode `auto` utilise le GPU.
- Utiliser `--workers N` (≈ nombre de cœurs / 2, max 8) ; chaque worker ouvre un Chromium.
- Faire tous les essais avec `--scale 0.35` (planche-contact) puis un seul rendu final.
- Gagner du temps : `config.shadows: false`, `config.resolution: "720p"` pour les brouillons, `--preset ultrafast` pour un aperçu, `--crf 18` pour le final.
- Whisper télécharge son modèle au premier lancement (~75 Mo `base`, ~500 Mo `small`) : accès Internet à huggingface.co requis. Sans accès : `tools/srt_to_words.py` avec un SRT.
- Disque : ~600 Mo (node_modules + Chromium) + les rendus.
