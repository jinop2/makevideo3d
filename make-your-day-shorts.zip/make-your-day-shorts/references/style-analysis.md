# Analyse des 6 vidéos de référence

Source : 6 MP4 verticaux. Mesures faites avec ffmpeg (scène, loudness), OCR des sous-titres et lecture de planches-contact. Les valeurs marquées `~` sont des estimations.

## 1. Fiche technique commune
| Mesure | Valeur |
|---|---|
| Format | 1080x1920 (9:16), 30 fps |
| Codec | HEVC vidéo, AAC 44,1 kHz stéréo |
| Durées | 58,9 s / 80,4 s / 72,5 s / 108,0 s / 77,5 s / 81,5 s |
| Audio | voix off continue + bed musical/ambiance, **aucun silence** (0 % de fenêtres < -45 dB sauf les 1-3 dernières secondes de fin) |
| Loudness intégrée | -17,6 / -17,4 / -17,7 / -14,4 / -20,3 / -14,5 LUFS (médiane ~ -17,5) |
| Dynamique (LRA) | 1,7 à 5,3 LU (voix très compressée) |
| Débit de parole | `~` 2,5 à 3 mots par seconde (un mot à l'écran toutes les 0,3 à 0,5 s) |

## 2. Deux familles visuelles

### Famille NÉON FLAT (vidéos 1, 2, 3)
- **Rendu** : 3D low-poly aplat, sans textures réalistes, couleurs saturées. Caméra très mobile (travelling, descente verticale, plongée dans un tuyau, orbite autour de la piscine).
- **Héros** : silhouette adulte fine, combinaison **orange** (`~#D96B0D` à `#FF7A00`), visage simple. Nom affiché en étiquette diégétique sur le décor (cabane).
- **Monde** : ville verticale. En bas : terre brune, cabanes en tôle/bois, pneus, déchets, conteneurs empilés. En haut : sols damier lavande/blanc (`~#EDDDFF`), piscines turquoise, palmiers, feux d'artifice, tapis rouge, tour des riches avec ascenseur doré.
- **Ciel** : dégradé magenta -> violet (`~#E11EA4` en haut du ciel, `~#5212AB` plus bas). Tours néon avec fenêtres en pixels allumés.
- **Sous-titres** : **mots en 3D intégrés à la scène**, centrés, une couleur différente par mot (bleu, vert, orange, rouge, blanc), contour sombre, parfois déformés/liquides (effet de mot « plongé » dans le décor).
- **Éléments d'interface** : cartes de commentaires TikTok stylisées (compteur de likes « 25,3 k », « 1 » cœur), panneau néon « 20000 € », jeu de nombres géants (« 20 »), compte à rebours (23:59 -> 0:00), bulle « ... » de chat, cadre « ? » de vote.
- **Transitions** : glitch/liquide, bande de film noir et blanc pour les flashbacks, dézoom soudain, plongée dans un tuyau (POV glissade).
- **Rythme** : coupes plus rares (~3,6 à 4,7 s de plan moyen) mais **mouvement caméra continu**. Dans la vidéo 1, les changements se font par fondus/morphs, pas par coupes sèches.
- **Mécanique d'interaction** : la vidéo 3 propose un vote (« choisis ... ») et affiche le commentaire gagnant (« tu le pousses dans la piscine ») qui devient la suite. Les vidéos 2 et 3 se terminent sur un cadre « ? » + mot « décide » : **les commentaires décident la suite**.

### Famille BLOCKY (vidéos 4, 5, 6)
- **Rendu** : monde 3D à blocs (personnages parallélépipédiques, mains carrées, visage simple yeux ronds + sourcil/bouche expressifs), matériaux plastiques lisses, lumière douce, ciel pastel au coucher de soleil (rose/violet/orangé) ou bleu jour. Profondeur de champ et brume sur les grands décors.
- **Héros** : garçon à blocs, cheveux bruns, vêtements gris-bleu **rapiécés** (pièces carrées, trous) = pauvreté lisible. Antagoniste : vieil homme blanc, haut-de-forme, moustache, chaîne en or (puis lunettes noires).
- **Échelle** : gratte-ciel de verre à perte de vue, dômes dorés, villes flottantes, piscines au sommet, nuages roses, puis **espace et lune**. Les chiffres montent : étage 44, 94, 200, 300, 391, 1000, 4979, 10000, « espace ».
- **HUD permanent** (vidéos 4 et 5) : badge « PARTIE N » en haut à gauche (texte jaune acide sur fond sombre, liseré jaune, coins arrondis) + jauge verticale « ÉTAGE n » sur le bord gauche avec petit encadré numérique.
- **Sous-titres** : **un mot à la fois**, centrés, à ~61-66 % de la hauteur, jaune acide (`~#E3FC2B`) avec **contour noir épais** et ombre, police sans-serif géométrique ultra grasse (type Montserrat Black / Extra Bold), minuscules. **Mot-clé** de la phrase en plus gros et/ou autre couleur (« DORÉ » en cyan, « 200 » géant en doré, « VILLE » en blanc/rouge). Mots courts (« et », « le ») plus petits.
- **Éléments diégétiques** : écran « SCANNING.. » avec barre de chargement, bandeau « NOUVEAU PROPRIÉTAIRE IDENTIFIÉ », panneau « DANGER, NE PAS TOUCHER L'EAU », étiquettes de zone en 3D (« QUARTIER JAUNE »), compteur flottant au-dessus du personnage (14), point d'exclamation au-dessus des têtes (alerte).
- **Rythme** : plan moyen ~1,4 s (vidéo 5), ~2,3 s (vidéos 4 et 6). Coupes sèches, zooms rapides, plans très serrés sur le visage (surprise : yeux ronds, bouche en O) en alternance avec plans géants d'établissement.
- **Ambiances par contraste** : jour pastel -> nuit noire avec grille néon orange et yeux rouges (suspense/horreur) -> bulle turquoise lumineuse (révélation). Vidéo 5 : mur de boules de couleur (salle de contrôle), vision en noir et blanc pour la révélation.
- **Fins** : fond dégradé sombre (bleu nuit, ou rose-violet), gros titre blanc à contour noir, sous-titre jaune. Exemples : « PARTIE 2 BIENTÔT » + question (« Qui a poussé [le méchant] ? ») ; « FIN » + « Tu veux une partie 3 ? ». La vidéo 6 s'arrête sur un plan de visage/bulle sans carte de fin visible.

## 3. Structures narratives observées (résumé, pas de copie)
- **Vidéo 4 (partie 1)** : ouverture par l'énoncé du principe du monde (plus on est riche, plus la maison est haute), description verticale (cabanes en bas -> tours -> milliardaires dans l'espace avec jacuzzi flottant), le héros pauvre raconte son quotidien (échelle cassée pour atteindre le trottoir, ami d'enfance à l'étage supérieur), règle d'exclusion (les gens d'en bas n'ont pas le droit de monter), événement déclencheur (tremblement de terre, objet doré tombé), scan du héros « nouveau propriétaire », écran de ville qui diffuse son visage, question finale.
- **Vidéo 5 (partie 2)** : reprise express (rappel du monde), accès au secret (ascenseur, espace, lune, palais), antagoniste révélé, salle de contrôle qui déplace cabanes et manoirs, retournement (chaque famille à la même hauteur), « le palais disparaît », « quelqu'un d'encore plus riche », écran FIN + question de partie 3.
- **Vidéo 6 (autre monde)** : ville inondée, règle (interdit de toucher l'eau), quartiers par couleur, gardiens/monstre, plateforme et tyrolienne, passage nuit/neon horreur, première fois que le héros croise quelqu'un qui lui ressemble « trait pour trait ».
- **Vidéos 1 à 3 (néon)** : héros pauvre, commentaires de spectateurs diégétiques, ascension de la tour, escalade de chiffres (20000 €), tuyau/glissade, soirée piscine des riches, rencontre avec un serveur, décision laissée aux commentateurs.

## 4. Limites de cette analyse
- Aucune transcription audio : le sandbox d'analyse n'avait pas de modèle Whisper. Le texte a été lu via OCR des sous-titres (accents approximatifs). Le **type de voix** (humaine ou synthétique, genre, ton) n'a donc pas été vérifié à l'oreille : à confirmer par l'utilisateur.
- Aucune information sur les outils de production réels des vidéos de référence (Roblox Studio, Blender, génération IA, etc.). Les deux modes A et B sont des méthodes de reproduction proposées, pas une rétro-ingénierie.
- Mesures de coupes par détection de scène (seuil 0,18) : sous-estiment les fondus et morphs (vidéo 1).


---

# Compléments : deux références supplémentaires (direction artistique élargie)

Le décor, l'ambiance et même le niveau de détail **varient selon le thème** : ce qui reste fixe, c'est la grammaire (voix off continue, un mot à l'écran, monde lisible, crochet de fin). Les deux vidéos suivantes montrent deux directions de plus.

## 5. Famille FLAT 2D / 2.5D (fichier `Sequence_04.mp4`, 39,6 s)
**Mesures** : fichier 1280x720 à 59,94 i/s, mais le contenu vertical n'occupe que ~442x720 au centre (bandes noires latérales, bords flous) : c'est un export de séquence de montage, pas un vrai 9:16. -17,3 LUFS, LRA 3,0 LU. ~6 coupes franches détectées : les changements se font par glissements/cartes successives (une « carte » toutes les 2 à 3 s).
- **Rendu** : illustration vectorielle à contours épais, aplats saturés, ombres plates, personnage **chibi** (grosse tête ronde, joues roses, sweat à capuche orange, poche kangourou, petits pieds), cabane en bois « CHEZ MOI », décharge (frigo, pneus, sacs), tours colorées (bleu, rose, jaune, violet) à fenêtres jaunes, enseigne « LUXE », nuages blancs, oiseaux.
- **Espace-temps** : on **change de décor à chaque idée** : sol brun (pauvre) -> coupes d'immeuble étage par étage (2, 10, 42, 131, 330) -> fusée, planètes -> île flottante des milliardaires -> salon de luxe damier avec caniche rose -> balcon d'un riche qui rit -> cartes d'interface.
- **Compteur d'étage empilé** : très gros chiffre blanc (~12 % de la hauteur) en haut au centre, libellé « ÉTAGE » doré en petit juste dessous, puis le sous-titre.
- **Sous-titres** : capitales **dorées** (dégradé jaune -> orange) avec contour brun foncé et ombre, petits (~70 px), position variable au centre ; plusieurs mots parfois.
- **Interface diégétique** : cartes de commentaires (pseudo, texte, cœur, « 12,4 K »), pilule « S'ABONNER » + compteur d'argent « 0 € -> 10 € » + bocal, étiquette « BONJOUR je m'appelle ? », bulle « ? » avec cœur, manette de jeu.
- **Fond d'appel à l'action** : sunburst violet/rose avec confettis, héros en gros plan qui lève la main.
- **Fin** (lue sur les sous-titres, audio non écouté) : appel à commenter (« le commentaire », « et n'oublie… »), bouton « ABONNÉ », compteur d'argent qui monte.
- **Durée** : ~40 s, donc une histoire courte à une seule idée suffit (voir `narrative-formula.md`, format court).

## 6. Famille CITY BLOCKY (fichier « Dans cette ville on est payé quand on a pas de chance », 74,5 s)
**Mesures** : 1080x1920, 30 i/s, HEVC, -14,1 LUFS, LRA 2,1 LU, 55 coupes détectées, plan moyen **~1,35 s** (le plus rapide des 8 vidéos).
- **Rendu** : personnages à blocs plus « Roblox » (pull jaune texturé, chevelure en blocs), mais **décor réaliste et lumineux** : avenue avec façades colorées, auvents, arbres, bus vert « LIGNE 13 », maisons à clôture blanche, arc-en-ciel, boutique violette « LC » à loterie, grand cochon tirelire, « CENTRE DE LA MALCHANCE » en verre, chambre en bois avec bibliothèque, salle de bain.
- **Gags visuels de cause à effet** : nuage noir de pluie qui suit le héros, bus qui fume, pluie de pièces/billets, jackpot en confettis.
- **Sous-titres** : **identiques** aux vidéos 4-6 (jaune acide mesuré `#E4FD2C`, contour noir, centre ~49 % en x, ~61-67 % en y) mais plus petits : hauteur de lettre courante ~72 px (jusqu'à ~106 px pour un mot-clé). Mot-clé en gros (« Mathis », « jackpot », « Malchance »). **Pas de badge PARTIE ni de jauge.**
- **Interface** : pastille d'argent (pièce dorée + pilule verte : « +500 € », « +1 000 000 € », « 0 € »), écran « ANALYSE EN COURS... 89 % » avec barre, afficheur rouge « MALCHANCE : 0 % », **téléphone plein écran** (en-tête turquoise « CENTRE DE LA MALCHANCE », texte qui se révèle ligne par ligne : « Félicitations, [prénom]. Tu es officiellement... la personne la plus malchanceuse de l'histoire »), notification bancaire « +85 064 430 € », « +1 000 000 000 € ».
- **Trame narrative observée** : règle du monde inversée en une phrase (la malchance paie) -> série de petits gags quotidiens (bus, pluie, loterie, téléphone cassé) -> le héros comprend la règle -> « Centre de la Malchance » scanne le héros -> message sur le téléphone révèle qu'il est le plus malchanceux, donc le plus riche -> pluie de billets, foule qui fête, dernier mot (« poisse ») sans carte de fin.
- **Prénom du héros** donné tôt (Mathis) : identification immédiate, répété dans le message final.

## 7. Ce que ça change pour le skill
1. **Quatre familles** de décor au lieu de deux : `fantasy` (tours géantes, ciel pastel), `city` (rue lumineuse réaliste en blocs), `neon` (néon plat), `toon` (2D adapté en 3D, chibi à contour épais). Voir `visual-grammar.md`, section 1.
2. **Le décor suit le thème** : bidonville/tours pour les riches-pauvres, avenue pour une histoire quotidienne, île/espace pour les milliardaires, salle de contrôle pour un système caché, etc.
3. **Formats courts acceptés** : 35 à 45 s (~105 à 125 mots) fonctionnent très bien (référence 2D de 39,6 s). Le format long (80 à 100 s) reste possible.
4. **Sous-titres recalibrés** : corps de base ~98 px (lettre ~72 px), mot-clé x1,45 ; préréglage doré en capitales pour la famille 2D.
5. **Nouveaux éléments d'interface** : compteur d'étage empilé, pastille d'argent, téléphone plein écran, bouton S'ABONNER + compteur, afficheur « MALCHANCE : 0 % », fond sunburst, confettis.
