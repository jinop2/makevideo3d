# API du moteur (kit/)

Tout se pilote par `projects/<nom>/story/shots.json` (plans), `story/cast.json` (personnages) et `config.json`. La plupart des plans s'écrivent en **JSON pur**, sans code. Le code n'est nécessaire que pour un décor ou un plan inédit.

Canevas logique 9:16 = **1080 x 1920**. Monde 3D : 1 unité = 1 mètre, personnage ~1,9 m, il regarde vers **+z**. La caméra par défaut regarde vers -z.

## 1. config.json
| Clé | Rôle |
|---|---|
| `title` | nom du fichier final |
| `resolution` | `540p`, `720p`, `1080p` (largeur ; hauteur 16/9) |
| `fps` | 30 par défaut |
| `sky` | ciel par défaut : `sunset day dawn night neon space void teal flatday burst` |
| `part` | numéro de partie (affiche le badge PARTIE N) ; `null` = pas de badge |
| `captions` | `true` : sous-titres mot par mot |
| `emph` | liste de mots-clés à mettre en gros (cyan ; chiffres en or) |
| `autoEmph` | `true` : emphase aussi les mots de 9 lettres et plus |
| `captionStyle` | `{ capY, capSize, capStroke, yellow, cyan }` pour régler les sous-titres |
| `gaugeLabel`, `gaugeMax` | libellé et maximum de la jauge (échelle logarithmique) |
| `toon` | `true` : matières à aplats + contour noir (famille `toon`) ; `outline` (épaisseur, 0,04), `ink` (couleur du trait) ; par plan : `"toon": false` |
| `captionPreset` | `yellow` (défaut) ou `gold` (capitales dorées, famille 2D) |
| `gaugeStyle` | `bar` (barre latérale + encadré, défaut) ou `stack` (gros chiffre + libellé au centre haut) |
| `grade` | filtre CSS global, ex. `"saturate(1.12) contrast(1.05)"` |
| `bloom` | halo lumineux global (0 = off ; 0,3 à 0,6 pour la nuit néon) |
| `shadows` | `false` pour accélérer le rendu |
| `voiceover` | fichier voix (copié par `new_project.py`) |
| `music`, `sfx`, `loudness` | réglages du mixage (`gainDb`, LUFS cible, `file` pour ta propre musique) |
| `fadeIn`, `fadeOut` | fondus noirs (secondes) |

## 2. story/cast.json
```json
{ "hero": { "skin": "#f0c59a", "hair": "#5b3a1e", "hairStyle": "spiky",
            "shirt": "#7f93b5", "pants": "#3b4c6b", "shoes": "#2a2a33",
            "patches": 5, "patchColor": "#a08a6a", "accessories": [], "scale": 1 } }
```
- `hairStyle` : `short`, `spiky`, `bald`.
- `style` : `"chibi"` (grosse tête ronde, petit corps, joues roses ; idéal avec `toon`). `hoodie: true` (capuche + poche), `blush: true` (joues sur un personnage normal).
- `accessories` : `tophat` (+ `hatColor`), `cap`, `mustache`, `sunglasses`, `glasses`, `chain`, `cane`, `backpack` (+ `backpackColor`).
- `patches` : nombre de pièces carrées rapiécées (signe visuel de pauvreté). `number` : numéro sur le maillot.
- Une couleur signature par personnage. Ne jamais la changer dans une histoire.

## 3. Un plan dans shots.json
```json
{ "id": "s012", "start": 10.2, "end": 12.0, "line": "les mots dits (pour mémoire)",
  "set": "slum", "setOpts": { "seed": 3 }, "sky": "sunset",
  "actors": [ { "id": "hero", "pos": [0,0,2], "ry": 0.2, "anim": "idle", "expr": "shock" } ],
  "cam": { "type": "push", "from": [3,1.7,9], "to": [1.2,1.6,6.2], "look": [0,1.5,2], "shake": 0.1 },
  "hud": { "floor": [0, 300] },
  "ui": [ { "t": "tag", "text": "Quartier 1", "at": [0,3,-3], "from": 0.3 } ],
  "in": { "type": "whip", "dir": 1 },
  "emph": ["secret"], "sfx": [ { "at": 0.1, "name": "whoosh", "gain": -8 } ] }
```
Les plans sont **contigus** : `end` d'un plan = `start` du suivant. Le dernier plan couvre jusqu'à `duration`.

### Champs
| Champ | Description |
|---|---|
| `set`, `setOpts` | décor (section 4) et ses options |
| `sky` | ciel du plan (écrase `config.sky`) ; `fog: [près, loin]` ; `shadows: false` pour les grandes vues |
| `actors[]` | personnages du plan (section 5) |
| `cam` | caméra (section 6) |
| `hud` | `floor` : nombre ou `[début, fin]` animé ; `style`: `bar`/`stack` ; `label`: texte à la place du nombre (`"ESPACE"`, `"???"`) ; `lines: true` : lignes de vitesse |
| `ui[]` | éléments d'interface (section 7) |
| `in` | transition d'entrée : `cut` (défaut), `flash`, `whip` (`dir` ±1), `zoom`, `fade`, `dip`, avec `dur` |
| `emph` | mots mis en gros dans ce plan, `emphColor` pour leur couleur |
| `captions: false` | pas de sous-titre pendant ce plan (écran de fin) |
| `badge: false` | cache le badge PARTIE sur ce plan |
| `endcard` | `{ title, question, bg:[3 couleurs] }` : écran de fin plein cadre (pas de 3D) |
| `sfx`, `amb` | sons : `[{at, name, gain, dur, seed, pitch}]` (`at` = secondes depuis le début du plan) ; `amb: {name, gain}` ambiance bouclée |

## 4. Décors (`set`)
| Nom | Contenu | Options utiles |
|---|---|---|
| `slum` | sol brun, cabanes numérotées, pneus, herbe, tours géantes derrière | `seed, shacks, numbers, tires, fence, ground` |
| `street` | route à tirets, maisons basses, lampadaires, arbres | `seed` |
| `skyline` | forêt de gratte-ciel + nuages | `count, hMin, hMax, rMax, kinds, clouds, seed` |
| `giantTower` | une tour géante au centre (bandes dorées) | `h, w, d, kind, bands` |
| `cloudDeck` | nuages roses, palais doré, bassin | `domeR, domeX, seed` |
| `palace` | hall doré, tapis rouge, colonnes, écran mural | `screenText` |
| `controlRoom` | mur de pastilles colorées, pupitre à boules | `cols, rows, seed` |
| `waterTown` | eau turquoise, plateformes jaunes, maisons, panneau danger | `platforms, seed` |
| `nightGrid` | nuit, plateformes à grille orange, yeux rouges | `platforms, eyeX, eyeY, eyeZ` |
| `poolDeck` | terrasse damier, piscine, palmiers, foule | `crowd` |
| `space` | étoiles, lune, plateforme flottante | |
| `plain` | sol neutre (gros plans) | `ground` |
| `flatCity` | décharge + cabane « CHEZ MOI » + tours colorées + enseigne LUXE (adapté de la 2D) | `shackX, luxText, homeText, seed` |
| `cutaway` | coupe d'immeuble : pièces ouvertes empilées | `floors, w, palette` |
| `island` | île flottante dorée, palmier, maison, planète à anneau, étoiles | |
| `luxRoom` | salon de luxe damier, fenêtre à rideaux, lustre, caniche rose | `dogColor` |
| `burst` | fond sunburst violet/rose rotatif (appel à l'action) | `c1, c2` |
| `avenue` | avenue lumineuse, façades à auvents, arbres, bus | `bus, busLabel, busX, busZ, shops:[textes], seed` |
| `facade` | grand bâtiment vitré avec enseigne | `text, color, wall` |
| `bedroom` | chambre : parquet, lit, bibliothèque | `wall` |

Kinds de tours : `glass`, `warm`, `pink`, `gold`, `night`, `toonBlue`, `toonPink`, `toonYellow`, `toonPurple`, `toonOrange`.

Décor perso : fichier `projects/<nom>/scenes/sets/mon-decor.js`
```js
import { registerSet } from '/engine/core.js';
import * as T from '/engine/blocky.js';
registerSet('maSalle', (T_, o = {}) => {
  const g = T.group(T.ground(40, 40, '#cfc8d8'), T.tower(6, 30, 6, { kind: 'gold' }));
  return { group: g, anim: t => { /* animation par temps */ } };
});
```
Primitives disponibles dans `T` : `box rbox cyl sphere plane ground group mat glow tower shack house goldDome cloud tree lamp tire crowd sign bus poodle canvasTex blockFigure toonify stage applyCamera project`. Kinds de tours `toon*` : `toonBlue toonPink toonYellow toonPurple toonOrange`.

## 5. Acteurs
`{ "id": "hero", "pos": [x,y,z], "ry": rotation, "anim": "walk", "expr": "shock", "s": 1.2 }`
- `ry` : rotation autour de Y (radians). `0` = face à la caméra par défaut ; `3.14` = de dos.
- `move: [[t,[x,y,z]], …]` : déplacement dans le plan ; `rotKeys: [[t,[ry]], …]`.
- `anims: [[0,"walk"],[1.2,"shock"]]` et `exprs: [[0,"neutral"],[1,"shock"]]` : changements dans le plan.
- `phase` : décalage d'animation (pour plusieurs personnages identiques).
- **Animations** : `idle walk run cheer shock wave point pointup climb fall sit crouch lookup arms`.
- **Expressions** : `neutral smile happy shock worry angry sad determined`.

## 6. Caméras (`cam`)
| Type | Champs | Usage |
|---|---|---|
| `push` (défaut) | `from`, `to`, `look`, `lookTo`, `fov` | poussée / travelling d'un point à un autre |
| `orbit` | `target`, `radius` (nombre ou `[a,b]`), `height`, `from`, `to` (angles), `fov` | tour autour d'un sujet |
| `dolly` | `keys: [[t,{pos,look,fov}], …]` | trajectoire libre, montée verticale le long d'une tour |
| `face` | `actor`, `dist` (nombre ou `[a,b]`), `angle`, `drift`, `up`, `fov` | gros plan visage |
Cadrage : largeur visible ≈ `2 x distance x tan(fov/2) x 0,5625`. Pour un rendu 2.5D plat : `fov` 24 à 34 et caméra loin (12 à 26 m).
Communs : `shake` (amplitude, ex. 0,1), `shakeFreq`, `roll` (radians), `ease` (`inOut`, `out`, `in`, `linear`).
Conseil : contre-plongée sur les tours = `look` très au-dessus de `pos` (ex. pos y=2, look y=150, fov 55-62). Ne jamais placer la caméra à l'intérieur d'un nuage ou d'un bâtiment.

## 7. `ui[]` (éléments superposés)
Chaque élément accepte `from` et `to` (secondes depuis le début du plan).
| `t` | Champs | Rendu |
|---|---|---|
| `tag` | `text`, `at: [x,y,z]` ou `{actor,dy}`, `color` | étiquette de lieu en capitales qui pop |
| `bang` | `actor` | « ! » jaune au-dessus de la tête |
| `panel` | `title`, `sub`, `progress:[a,b]`, `y`, `bg`, `accent` | écran « SCANNING.. » avec barre ou bandeau d'info |
| `comment` | `user`, `txt`, `likes` | carte commentaire TikTok (votes des spectateurs) |
| `number` | `text`, `color`, `size` | nombre géant doré (200, 10000…) |
| `float` | `text`, `actor` | « +14 » qui monte et disparaît |
| `flash` | | flash blanc court |
| `money` | `text` (« +500 € »), `actor` | pastille d'argent (pièce + pilule verte) qui flotte au-dessus du personnage |
| `phone` | `header`, `color`, `blocks:[{text,color,size,from,gap}]` | téléphone plein écran, blocs de texte qui apparaissent aux instants `from` |
| `subscribe` | `amount:[0,10]`, `label`, `unit`, `y` | bouton « + S'ABONNER » + compteur d'argent qui monte |
| `meter` | `label`, `value:[0,100]`, `unit`, `color` | afficheur noir « MALCHANCE : 0 % » avec barre |
| `confetti` | `n` | confettis 2D qui tombent |

## 8. Plan personnalisé en code
`projects/<nom>/scenes/shots/s042.js`, utilisé si le plan `s042` n'a pas de `set` :
```js
import { registerShot } from '/engine/core.js';
registerShot('s042', {
  init(T, { shot }) { const stage = T.stage({ sky: 'night' }); /* construire la scène */ return { stage }; },
  draw(s, lt, info, T) { T.applyCamera(s.stage.camera, { type: 'orbit', target: [0,1,0], radius: 6 }, lt, info.dur); },
  overlay(g, lt, info, s) { /* dessin 2D facultatif */ },
});
```
Dans `init`, retourne `{ stage, … }` ; `draw` met à jour caméra/objets ; `overlay` dessine en 2D (canevas 1080x1920).

## 9. Commandes
```
node render.mjs --project projects/<nom> --sheet --scale 0.4      planche-contact (une image par plan)
node render.mjs --project projects/<nom> --stills 3.5,12 --scale .5   images fixes
node render.mjs --project projects/<nom> --from 10 --to 20 --scale 0.5   aperçu vidéo d'un extrait
node render.mjs --project projects/<nom>                           rendu final -> build/video_silent.mp4
python audio/mix.py --project projects/<nom>                       voix + musique + SFX -> out/<titre>.mp4
```
Options : `--workers N`, `--crf 18`, `--preset ultrafast|medium`, `--gl gpu|swiftshader`, `--debug` (affiche id de plan et temps).
En cas d'erreur de plan, une carte rouge « ERREUR sNNN » apparaît dans l'image et le message est listé en fin de rendu.
