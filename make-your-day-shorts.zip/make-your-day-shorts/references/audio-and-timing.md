# Audio et timing

## 1. Voix off
- Langue : français, première personne, ton de confidence rapide et soutenu, **continu** (aucune respiration longue : sur les 6 références il n'y a pas de silence avant la toute fin).
- Débit : 2,5 à 3 mots par seconde. Valider le nombre de mots avant enregistrement (voir `narrative-formula.md`).
- Voix compressée et présente : pas de réverbération, présence dans les médiums (centroïde spectral des références ~1,9 à 2,4 kHz).
- Type de voix des références : **non vérifié à l'oreille** (pas de transcription possible lors de l'analyse). Demander à l'utilisateur quel outil/voix il utilise (ElevenLabs ou autre) et réutiliser les mêmes réglages d'une partie à l'autre pour la cohérence de série.
- Enregistrer par blocs de phrases, exporter un seul fichier voix final en WAV 44,1 kHz.

## 2. Timestamps mot par mot
1. **Whisper (par défaut)** : `python tools/transcribe.py --project projects/<nom> --script input/script.txt --lang fr --model small`. Le texte exact de la voix off est aligné sur l'audio (correspondance attendue ≥ 90 %) : les sous-titres gardent l'orthographe du script.
2. **Plan B sans Whisper** : fournir un SRT (sous-titrage automatique de CapCut, Premiere, YouTube) puis `python tools/srt_to_words.py --project projects/<nom> --srt input/voix.srt`. La précision au mot est plus faible (répartition par longueur de mot dans chaque ligne).
3. Sortie : `timeline/words.json` (`mot, début, fin`), `sentences.json`, `transcript.txt`. Relire `transcript.txt` : tout mot mal aligné (nombres, noms propres) se corrige dans `words.json`.
4. **Brouillon de découpage** : `python tools/beats.py --project projects/<nom> --endcard "PARTIE 2\nBIENTÔT|Question ?"` crée `story/shots.json` avec des plans de ~1,9 s (réglable `--target`, `--max`, `--min`). Il ne choisit pas les décors : remplir `set`, `cam`, `actors`, `hud`, `ui` ensuite (`engine-api.md`).

## 3. Musique
- Un bed continu sous la voix. Pas de mélodie qui rivalise avec la voix.
- Ambiances générées (`python audio/music.py --list`) : `mystery, tension, action, wonder, hopeful, sad, triumph, playful, calm, dark, epic`.
- Plan de musique dans `story/shots.json` : `"music": [{"start":0,"end":20,"mood":"wonder","intensity":0.5},{"start":20,"end":55,"mood":"tension","intensity":0.7},{"start":55,"end":85,"mood":"epic","intensity":0.8}]`.
  Changer de section aux basculements du récit (hook, règles, déclencheur, révélation, cliffhanger).
- Sa propre musique : `config.music.file` (chemin relatif au projet), bouclée et ajustée à la durée.
- Niveau : environ -17 dB sous la voix (`music.gainDb`), ducking automatique de -9 dB quand la voix parle.

## 4. SFX
Liste complète : `python audio/sfx.py --list`. Principaux : `whoosh, swish, impact, hit, riser, slowmo, freeze, tick, clock, heartbeat, pop, blip, counter, ding, shimmer, stinger, footstep, kick, whistle, cheer, applause, murmur, rain, thunder, wind, roomtone, city, hum, powerup, glitch, flash, buzz`.
Placement dans un plan : `"sfx": [{"at": 0.2, "name": "whoosh", "gain": -8}]` (`at` = secondes depuis le début du plan). Ambiance bouclée : `"amb": {"name": "city", "gain": -24}`. On peut aussi utiliser un fichier : `"name": "sons/porte.wav"`.
| Moment | SFX |
|---|---|
| Mot-clé en gros ou chiffre qui monte | `pop` ou `counter` (-12 à -16) |
| Whip / zoom rapide | `whoosh` / `swish` (-8) |
| Révélation (écran, objet doré) | `riser` 1 à 2 s avant, puis `impact` / `stinger` (-4) |
| Écran SCANNING | `blip` répété, puis `ding` |
| Danger (nuit néon) | `heartbeat`, `hum`, `buzz`, `glitch` |
| Foule / ville | `murmur` ou `city` en ambiance (-20 à -28) |
| Écran de fin | `stinger` court puis coupure nette |
Ne pas empiler plus de 2 effets au même instant ; garder la voix dégagée.

## 5. Mixage et niveaux
- Commande : `python audio/mix.py --project projects/<nom>` (voix + musique + SFX + ambiances, ducking, normalisation, assemblage avec `build/video_silent.mp4` -> `out/<titre>.mp4`).
- Mesure des vidéos de référence : -14,4 à -20,3 LUFS (médiane ~ -17,5). Cible du kit : `config.loudness` = **-15** (entre -14 et -16 pour TikTok). Test réalisé : sortie à -14,9 LUFS pour une cible de -15.
- Crête vraie max -1,5 dBTP. Fondu de sortie via `config.fadeOut`.
- Options : `--no-music`, `--no-sfx`.
