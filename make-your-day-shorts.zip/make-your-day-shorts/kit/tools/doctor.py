"""tools/doctor.py : vérifie que tout est installé.   python tools/doctor.py [--install]"""
import os, shutil, subprocess, sys

def ok(name, good, hint=""):
    print(("OK   " if good else "MANQUE") + f"  {name}" + ("" if good else f"   -> {hint}"))
    return good

root = os.path.join(os.path.dirname(__file__), "..")
res = []
res.append(ok("ffmpeg", shutil.which("ffmpeg") is not None, "Windows: winget install Gyan.FFmpeg | macOS: brew install ffmpeg | Linux: apt install ffmpeg"))
res.append(ok("ffprobe", shutil.which("ffprobe") is not None, "installé avec ffmpeg"))
res.append(ok("node >= 18", shutil.which("node") is not None, "installer Node.js LTS"))
res.append(ok("node_modules (three, playwright, police)", os.path.isdir(os.path.join(root, "node_modules", "three")) and os.path.isdir(os.path.join(root, "node_modules", "@fontsource", "montserrat")), "npm install"))
for mod, pipname in [("numpy", "numpy"), ("scipy", "scipy"), ("faster_whisper", "faster-whisper")]:
    try:
        __import__(mod); res.append(ok(f"python: {pipname}", True))
    except Exception:
        res.append(ok(f"python: {pipname}", False, f"python -m pip install {pipname}  (ajouter --break-system-packages sur Linux géré)"))
chromium = os.environ.get("CHROMIUM_PATH")
if chromium: res.append(ok(f"Chromium via CHROMIUM_PATH ({chromium})", os.path.exists(chromium), "chemin invalide"))
else: print("INFO  Chromium : sera cherché via Playwright. Si le rendu échoue : npx playwright install chromium  (ou définir CHROMIUM_PATH)")
if "--install" in sys.argv:
    subprocess.run(["npm", "install"], cwd=root, shell=(os.name == "nt"))
    subprocess.run(["npx", "playwright", "install", "chromium"], cwd=root, shell=(os.name == "nt"))
    subprocess.run([sys.executable, "-m", "pip", "install", "numpy", "scipy", "faster-whisper"])
print("\nTout est prêt." if all(res) else "\nCorrige les lignes MANQUE puis relance (ou : python tools/doctor.py --install).")
