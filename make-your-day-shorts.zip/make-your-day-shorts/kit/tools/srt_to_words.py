"""tools/srt_to_words.py : plan B si Whisper n'est pas disponible. Convertit un SRT (CapCut, Premiere, YouTube…)
en timeline/words.json en répartissant les mots de chaque ligne selon leur longueur.

  python tools/srt_to_words.py --project projects/ma-ville --srt input/voix.srt
"""
import argparse, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import load_json, save_json, sentences_from_words, write_timeline

ap = argparse.ArgumentParser(); ap.add_argument("--project", required=True); ap.add_argument("--srt", required=True)
a = ap.parse_args()
srt = a.srt if os.path.exists(a.srt) else os.path.join(a.project, a.srt)
raw = open(srt, encoding="utf-8-sig").read().replace("\r", "")
tc = lambda s: (lambda h, m, x, ms: int(h) * 3600 + int(m) * 60 + int(x) + int(ms) / 1000)(*re.split(r"[:,.]", s.strip()))
words = []
for blk in re.split(r"\n\s*\n", raw.strip()):
    lines = [l for l in blk.split("\n") if l.strip()]
    m = next((re.match(r"(\S+)\s*-->\s*(\S+)", l) for l in lines if "-->" in l), None)
    if not m: continue
    t0, t1 = tc(m.group(1)), tc(m.group(2))
    toks = " ".join(l for l in lines if "-->" not in l and not l.strip().isdigit()).split()
    if not toks: continue
    tot = sum(len(re.sub(r"\W", "", t)) + 2 for t in toks); t = t0
    for tok in toks:
        d = (t1 - t0) * (len(re.sub(r"\W", "", tok)) + 2) / tot
        words.append({"word": tok, "start": round(t, 3), "end": round(t + d * 0.92, 3)}); t += d
if not words: sys.exit("aucun mot trouvé dans le SRT")
write_timeline(os.path.join(a.project, "timeline"), words, sentences_from_words(words), "srt")
