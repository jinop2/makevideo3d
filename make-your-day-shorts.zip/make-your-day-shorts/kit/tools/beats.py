"""tools/beats.py : brouillon de story/shots.json à partir des timestamps (rythme 'blocky' : plans de 1,4 à 2,4 s).

  python tools/beats.py --project projects/ma-ville [--target 1.9] [--max 2.6] [--min 1.0] [--lead 0.12] [--endcard "PARTIE 2\\nBIENTÔT|Qui a… ?"]

Chaque plan reçoit : id, start, end, line (les mots dits), et un décor à choisir ("set": "TODO").
Tu (ou Claude) remplis ensuite set / cam / actors / hud / ui, puis relances render.mjs --sheet.
"""
import argparse, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import load_json, save_json

ap = argparse.ArgumentParser()
ap.add_argument("--project", required=True)
ap.add_argument("--target", type=float, default=1.9)
ap.add_argument("--max", type=float, default=2.6)
ap.add_argument("--min", type=float, default=1.0)
ap.add_argument("--lead", type=float, default=0.12)
ap.add_argument("--tail", type=float, default=0.4, help="secondes d'image après le dernier mot avant la carte de fin")
ap.add_argument("--endcard", default="", help="« TITRE|question » pour ajouter un écran de fin (\\n = saut de ligne)")
ap.add_argument("--force", action="store_true")
a = ap.parse_args()
cfg = load_json(os.path.join(a.project, "config.json"))
words = load_json(os.path.join(a.project, "timeline", "words.json"))["words"]
out_path = os.path.join(a.project, "story", "shots.json")
if os.path.exists(out_path) and not a.force:
    sys.exit(f"{out_path} existe déjà (utilise --force pour l'écraser)")

# 1) groupes de mots : coupe sur ponctuation forte / virgule, puis découpe les groupes trop longs
groups, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    nxt = words[i + 1] if i + 1 < len(words) else None
    gap = (nxt["start"] - w["end"]) if nxt else 9
    if re.search(r"[.?!…:;,]['\"”’)]*$", w["word"]) or gap > 0.5 or not nxt:
        groups.append(cur); cur = []
dur = lambda g: g[-1]["end"] - g[0]["start"]
chunks = []
for g in groups:
    if dur(g) <= a.max:
        chunks.append(g); continue
    n = max(2, round(dur(g) / a.target)); size = max(1, round(len(g) / n))
    for k in range(0, len(g), size):
        chunks.append(g[k:k + size])
# 2) fusionne les fragments trop courts (jamais à cheval sur une fin de phrase)
strong = lambda g: bool(re.search(r"[.?!…]['\"”’)]*$", g[-1]["word"]))
merged, pending = [], []
for c in chunks:
    c = pending + c; pending = []
    if dur(c) < a.min:
        if merged and not strong(merged[-1]) and dur(merged[-1]) + dur(c) <= a.max + 0.6: merged[-1] += c
        else: pending = c
    else: merged.append(c)
if pending:
    if merged: merged[-1] += pending
    else: merged.append(pending)
# 3) plans contigus : début = premier mot - lead ; fin = début du plan suivant
shots = []
for i, c in enumerate(merged):
    start = 0.0 if i == 0 else round(max(0.0, c[0]["start"] - a.lead), 3)
    shots.append({"id": f"s{i + 1:03d}", "start": start, "end": None, "line": " ".join(w["word"] for w in c), "set": "TODO"})
last_word_end = words[-1]["end"]
for i, s in enumerate(shots):
    s["end"] = shots[i + 1]["start"] if i + 1 < len(shots) else round(last_word_end + a.tail, 3)
    s["start"] = round(s["start"], 3); s["end"] = round(s["end"], 3)
end_t = shots[-1]["end"]
if a.endcard:
    title, _, q = a.endcard.partition("|")
    shots.append({"id": f"s{len(shots) + 1:03d}", "start": end_t, "end": round(end_t + 2.6, 3), "line": "(écran de fin)", "captions": False,
                  "endcard": {"title": title.replace("\\n", "\n"), "question": q.strip(), "bg": ["#1a2a7a", "#0a1040", "#04061a"]}})
    end_t = shots[-1]["end"]
save_json(out_path, {"duration": end_t, "shots": shots})
cfg["duration"] = end_t; save_json(os.path.join(a.project, "config.json"), cfg)
lens = sorted(s["end"] - s["start"] for s in shots if "endcard" not in s)
print(f"{len(shots)} plans, durée totale {end_t:.1f} s, plan médian {lens[len(lens)//2]:.2f} s  ->  {out_path}")
