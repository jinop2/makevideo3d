"""tools/new_project.py : crée le dossier d'un projet (une partie / une vidéo).

  python tools/new_project.py --name ma-ville --voice chemin/voix.mp3 [--script texte.txt] [--part 1] [--sky sunset]

Résultat : projects/<name>/ avec config.json, input/, timeline/, story/, scenes/, build/, out/.
"""
import argparse, os, shutil, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import probe_duration, save_json

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
ap.add_argument("--voice", required=True, help="fichier audio de la voix off (mp3/wav/m4a)")
ap.add_argument("--script", help="texte exact de la voix off (conserve l'orthographe pour les sous-titres)")
ap.add_argument("--part", type=int, default=0, help="numéro de partie (0 = pas de badge PARTIE)")
ap.add_argument("--resolution", default="1080p", choices=["540p", "720p", "1080p"])
ap.add_argument("--fps", type=int, default=30)
ap.add_argument("--sky", default="sunset", choices=["sunset", "day", "dawn", "night", "neon", "space", "void", "teal"])
ap.add_argument("--title", default="")
a = ap.parse_args()

root = os.path.join("projects", a.name)
for d in ["input", "timeline", "story", "scenes/sets", "scenes/shots", "build", "out"]:
    os.makedirs(os.path.join(root, d), exist_ok=True)
voice_dst = os.path.join("input", "voiceover" + os.path.splitext(a.voice)[1].lower())
shutil.copy2(a.voice, os.path.join(root, voice_dst))
script_dst = None
if a.script:
    script_dst = os.path.join("input", "script" + os.path.splitext(a.script)[1].lower())
    shutil.copy2(a.script, os.path.join(root, script_dst))
dur = probe_duration(os.path.join(root, voice_dst))
cfg = {"title": a.title or a.name, "resolution": a.resolution, "fps": a.fps, "sky": a.sky,
       "part": a.part or None, "captions": True, "emph": [], "autoEmph": False, "gaugeLabel": "ÉTAGE", "gaugeMax": 10000,
       "voiceover": voice_dst.replace("\\", "/"), "script": script_dst.replace("\\", "/") if script_dst else None,
       "duration": round(dur + 2.5, 3), "fadeIn": 0, "fadeOut": 0.4,
       "music": {"enabled": True, "gainDb": -17}, "sfx": {"enabled": True, "gainDb": -6}, "loudness": -15}
save_json(os.path.join(root, "config.json"), cfg)
save_json(os.path.join(root, "story", "cast.json"), {"hero": {"skin": "#f0c59a", "hair": "#5b3a1e", "hairStyle": "spiky", "shirt": "#7f93b5", "pants": "#3b4c6b", "patches": 5, "patchColor": "#a08a6a"}})
print(f"projet créé : {root}  (voix {dur:.1f} s, {a.resolution} 9:16 à {a.fps} i/s, ciel {a.sky})")
print("étapes suivantes : transcribe.py -> beats.py -> écrire story/shots.json -> render.mjs --sheet -> render.mjs -> audio/mix.py")
