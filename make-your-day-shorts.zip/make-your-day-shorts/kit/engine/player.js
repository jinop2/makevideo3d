// engine/player.js — charge un projet, associe le temps global à un plan, rend une image (window.renderFrame).
import { E, clamp, ease, prog, text, getShot, getSet, wordTime } from './core.js';
import * as T from './blocky.js';
import './sets.js';
import * as H from './hud.js';

const q = new URLSearchParams(location.search), PROJ = '/project';
const errors = (window.ERRORS = []);
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
let main, mg, bufA, bufB, glCanvas;

async function loadFonts() {
  for (const w of [700, 800, 900]) { try { const ff = new FontFace('Montserrat', `url(/node_modules/@fontsource/montserrat/files/montserrat-latin-${w}-normal.woff2)`, { weight: String(w) }); await ff.load(); document.fonts.add(ff); } catch (e) { console.log('font missing Montserrat', w); } }
}
async function boot() {
  const j = async (p, opt) => { const r = await fetch(`${PROJ}/${p}`); if (!r.ok) { if (opt) return null; throw new Error(`${p}: HTTP ${r.status}`); } return r.json(); };
  const cfg = await j('config.json'), story = await j('story/shots.json'), tl = await j('timeline/words.json', true), cast = (await j('story/cast.json', true)) || {};
  const short = { '540p': 540, '720p': 720, '1080p': 1080 }[cfg.resolution || '1080p'] || 1080, scale = +(q.get('scale') || 1);
  const outW = Math.round((short * scale) / 2) * 2, outH = Math.round(((short * 16) / 9) * scale / 2) * 2;
  Object.assign(E, { fps: cfg.fps || 30, cfg, words: tl ? tl.words || tl : [], shots: story.shots, cast, outW, outH, PX: outW / E.W });
  await loadFonts();
  main = document.getElementById('main'); main.width = outW; main.height = outH; mg = main.getContext('2d', { willReadFrequently: false });
  bufA = mk(outW, outH); bufB = mk(outW, outH); glCanvas = mk(outW, outH); T.getRenderer(glCanvas);
  const list = await (await fetch('/__manifest')).json();
  for (const f of list) { try { await import(f); } catch (e) { errors.push(`import ${f}: ${e.message}`); console.log('IMPORT ERROR', f, e.message); } }
  const dur = story.duration || cfg.duration || E.shots[E.shots.length - 1].end;
  window.DURATION = dur; window.TOTAL_FRAMES = Math.ceil(dur * E.fps); window.OUT = [outW, outH];
  window.SHOT_LIST = E.shots.map(s => ({ id: s.id, start: s.start, end: s.end, ok: !!(s.set || s.endcard || getShot(s.id)) }));
  window.READY = true;
}

// ---------- construction d'un plan JSON ----------
function buildScene(shot) {
  const sk = shot.sky || E.cfg.sky || 'sunset';
  const st = T.stage({ sky: sk, fog: shot.fog, fov: shot.cam?.fov || 45, bloom: shot.bloom ?? E.cfg.bloom ?? 0, shadows: shot.shadows ?? (E.cfg.shadows !== false), shadowSize: shot.shadowSize || 14, sunI: shot.sunI, ambient: shot.ambient });
  const def = getSet(shot.set || 'plain'); if (!def) throw new Error(`décor inconnu: ${shot.set}`);
  const S = def(T, shot.setOpts || {}); st.add(S.group);
  const actors = {};
  for (const a of shot.actors || []) {
    const outfit = { ...(E.cast[a.id] || {}), ...(a.outfit || {}) }; if (a.s) outfit.scale = (outfit.scale || 1) * a.s;
    const fig = T.blockFigure(outfit), holder = new T.THREE.Group(); holder.add(fig.root); st.add(holder); actors[a.id] = { fig, holder, def: a, expr: null };
  }
  if (shot.toon ?? E.cfg.toon) T.toonify(st.scene, { outline: shot.outline ?? E.cfg.outline ?? 0.04, ink: E.cfg.ink || '#1a1020' });
  return { st, S, actors };
}
function applyActors(state, lt, shot) {
  for (const id in state.actors) {
    const A = state.actors[id], a = A.def;
    const pos = a.move ? key3(lt, a.move) : a.pos || [0, 0, 0]; A.holder.position.set(...pos);
    const ry = a.rotKeys ? key3(lt, a.rotKeys)[0] : a.ry ?? 0; A.holder.rotation.y = ry;
    const exprs = a.exprs || [[0, a.expr || 'neutral']]; let ex = exprs[0][1]; for (const [tt, e] of exprs) if (lt >= tt) ex = e;
    if (ex !== A.expr) { A.fig.setExpr(ex); A.expr = ex; }
    const anims = a.anims || [[0, a.anim || 'idle']]; let an = anims[0][1], t0 = 0; for (const [tt, n] of anims) if (lt >= tt) { an = n; t0 = tt; }
    A.fig.animate(an, lt + (a.phase || 0));
    if (a.spin) A.holder.rotation.z = lt * a.spin;
  }
}
function key3(t, frames) { // interpolation linéaire par morceaux de [[t,[x,y,z]],…]
  if (t <= frames[0][0]) return frames[0][1];
  for (let i = 1; i < frames.length; i++) if (t <= frames[i][0]) { const [t0, v0] = frames[i - 1], [t1, v1] = frames[i], k = ease.inOut((t - t0) / (t1 - t0)); return v0.map((x, n) => x + (v1[n] - x) * k); }
  return frames[frames.length - 1][1];
}
const cache = new Map();
function getState(shot) {
  if (cache.has(shot.id)) return cache.get(shot.id);
  for (const [k, v] of cache) if (cache.size >= 2) { v.st?.dispose?.(); v.custom?.dispose?.(); cache.delete(k); }
  const custom = getShot(shot.id);
  let s; if (custom && !shot.set) { const st = custom.init(T, { shot }); s = { custom: st, st: st.stage || st, def: custom, actors: {} }; } else s = buildScene(shot);
  cache.set(shot.id, s); return s;
}

// ---------- dessin d'un plan dans un buffer 2D ----------
function drawShot(buf, shot, lt) {
  const g = buf.getContext('2d'); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.filter = 'none';
  g.fillStyle = '#000'; g.fillRect(0, 0, buf.width, buf.height); g.setTransform(E.PX, 0, 0, E.PX, 0, 0);
  const dur = shot.end - shot.start, gt = shot.start + lt;
  try {
    if (shot.endcard) { H.endCard(g, lt / Math.max(0.01, dur), shot.endcard); return; }
    const s = getState(shot);
    if (s.def) { s.def.draw(s.custom, lt, { shot, dur, globalT: gt, p: clamp(lt / dur) }, T); s.st.render(); }
    else {
      applyActors(s, lt, shot); T.applyCamera(s.st.camera, shot.cam || { type: 'push', from: [0, 2, 8], look: [0, 1.5, 0] }, lt, dur, s); s.S.anim?.(lt);
      const tg = s.st.camera.position.clone().add(new T.THREE.Vector3(0, 0, 0)); // le soleil suit la zone visible pour garder des ombres nettes
      const f = (shot.actors && shot.actors[0] && s.actors[shot.actors[0].id]?.holder.position) || new T.THREE.Vector3(0, 0, 0);
      s.st.sun.target.position.copy(f); s.st.sun.position.copy(f).add(new T.THREE.Vector3(...s.st.sky.sunPos).normalize().multiplyScalar(60)); s.st.sun.target.updateMatrixWorld();
      s.st.render();
    }
    g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(glCanvas, 0, 0, buf.width, buf.height); g.restore();
    overlay(g, shot, lt, dur, gt, s);
  } catch (e) {
    const msg = `${shot.id}@${lt.toFixed(2)}: ${e.message}`; if (!errors.includes(msg) && errors.length < 100) errors.push(msg); console.log('SHOT ERROR', msg, e.stack?.split('\n')[1]);
    g.setTransform(E.PX, 0, 0, E.PX, 0, 0); g.fillStyle = '#301020'; g.fillRect(0, 0, E.W, E.H); text(g, 'ERREUR ' + shot.id, E.W / 2, E.H / 2 - 40, { size: 70, color: '#ff6f61' }); text(g, e.message.slice(0, 60), E.W / 2, E.H / 2 + 40, { size: 34, color: '#fff', weight: 700 });
  }
}
function screenOf(s, ref) { // ref = [x,y,z] | 'actor' | {actor, dy}
  if (Array.isArray(ref)) return T.project(s.st.camera, ref);
  const id = typeof ref === 'string' ? ref : ref.actor, A = s.actors[id]; if (!A) return { x: E.W / 2, y: E.H / 2, visible: false };
  const p = A.fig.headPos(); return T.project(s.st.camera, [p.x, p.y + (ref.dy ?? 0.55), p.z]);
}
function overlay(g, shot, lt, dur, gt, s) {
  if (shot.hud?.lines) H.lines(g, lt);
  for (const u of shot.ui || []) {
    const a = u.from ?? 0, b = u.to ?? dur; if (lt < a || lt > b) continue; const k = clamp((lt - a) / (u.in ?? 0.25)), kk = (lt - a) / Math.max(0.01, b - a);
    if (u.t === 'tag') { const p = u.at ? screenOf(s, u.at) : { x: u.x ?? E.W / 2, y: u.y ?? E.H * 0.2, visible: true }; if (p.visible) H.tag(g, u.text, p.x, p.y, { sc: ease.outBack(k), color: u.color }); }
    else if (u.t === 'bang') { const p = screenOf(s, { actor: u.actor, dy: 0.7 }); if (p.visible) H.bang(g, p.x, p.y, lt); }
    else if (u.t === 'panel') { const pr = u.progress ? u.progress[0] + (u.progress[1] - u.progress[0]) * kk : null; H.panel(g, { ...u, progress: pr }, k); }
    else if (u.t === 'comment') H.commentCard(g, u, k);
    else if (u.t === 'number') H.bigNumber(g, u.text, k, u);
    else if (u.t === 'float') { const p = u.actor ? screenOf(s, { actor: u.actor, dy: 0.6 }) : { x: E.W / 2, y: E.H * 0.45 }; H.floatText(g, u.text, p.x, p.y, kk, u); }
    else if (u.t === 'flash') H.flash(g, 1 - kk);
    else if (u.t === 'money') { const p = u.actor ? screenOf(s, { actor: u.actor, dy: 0.9 }) : { x: E.W / 2, y: E.H * 0.3, visible: true }; if (p.visible) H.moneyPill(g, u.text, p.x, p.y - 40 * ease.out(kk), k, u); }
    else if (u.t === 'phone') H.phone(g, u, lt - a);
    else if (u.t === 'subscribe') H.subscribe(g, u, k, lt - a);
    else if (u.t === 'meter') H.meter(g, u, u.value ? u.value[0] + (u.value[1] - u.value[0]) * ease.inOut(kk) : 0, k);
    else if (u.t === 'confetti') H.confetti(g, gt, u.n || 70);
  }
  const sh = shot.custom || getShot(shot.id); if (sh?.overlay) { g.save(); sh.overlay(g, lt, { shot, dur, globalT: gt }, s.custom || s); g.restore(); }
  if (E.cfg.part && shot.badge !== false) H.badge(g, `PARTIE ${E.cfg.part}`);
  if (shot.hud?.floor !== undefined) { const f = shot.hud.floor, v = Array.isArray(f) ? f[0] + (f[1] - f[0]) * ease.inOut(lt / dur) : f, st_ = shot.hud.style || E.cfg.gaugeStyle || 'bar', lab = E.cfg.gaugeLabel || 'ÉTAGE'; if (st_ === 'stack') H.floorStack(g, v, { label: lab, text: shot.hud.label }); else H.gauge(g, v, { max: E.cfg.gaugeMax || 10000, label: lab, text: shot.hud.label }); }
}

// ---------- image finale : transitions + sous-titres + fondus ----------
const SHOT_AT = t => { const S = E.shots; for (let i = 0; i < S.length; i++) if (t < S[i].end) return i; return S.length - 1; };
window.renderFrame = function (f) {
  const t = f / E.fps, i = SHOT_AT(t), shot = E.shots[i], lt = t - shot.start;
  drawShot(bufA, shot, lt);
  const tr = shot.in || { type: 'cut' }, tdur = tr.dur ?? (tr.type === 'whip' ? 0.25 : 0.3), W = main.width, H_ = main.height;
  mg.setTransform(1, 0, 0, 1, 0, 0); mg.globalAlpha = 1; mg.globalCompositeOperation = 'source-over'; mg.filter = E.cfg.grade || 'none';
  if (tr.type !== 'cut' && i > 0 && lt < tdur) {
    const prev = E.shots[i - 1], k = ease.inOut(lt / tdur); drawShot(bufB, prev, t - prev.start);
    if (tr.type === 'flash') { mg.drawImage(bufA, 0, 0); mg.filter = 'none'; mg.globalAlpha = (1 - lt / tdur) ** 2; mg.fillStyle = '#fff'; mg.fillRect(0, 0, W, H_); }
    else if (tr.type === 'fade') { mg.drawImage(bufB, 0, 0); mg.globalAlpha = k; mg.drawImage(bufA, 0, 0); }
    else if (tr.type === 'dip') { mg.drawImage(k < 0.5 ? bufB : bufA, 0, 0); mg.filter = 'none'; mg.globalAlpha = k < 0.5 ? k * 2 : (1 - k) * 2; mg.fillStyle = '#000'; mg.fillRect(0, 0, W, H_); }
    else if (tr.type === 'whip') { const dir = tr.dir || 1; for (let s = 0; s < 4; s++) { mg.globalAlpha = 0.34; mg.drawImage(bufB, -dir * k * W * 1.1 - dir * s * W * 0.02, 0); mg.drawImage(bufA, dir * (1 - k) * W * 1.1 + dir * s * W * 0.02, 0); } }
    else if (tr.type === 'zoom') { mg.drawImage(bufB, 0, 0); const s = 1.2 - 0.2 * k; mg.globalAlpha = k; mg.translate(W / 2, H_ / 2); mg.scale(s, s); mg.drawImage(bufA, -W / 2, -H_ / 2); mg.setTransform(1, 0, 0, 1, 0, 0); }
    else mg.drawImage(bufA, 0, 0);
  } else mg.drawImage(bufA, 0, 0);
  mg.globalAlpha = 1; mg.filter = 'none'; mg.setTransform(E.PX, 0, 0, E.PX, 0, 0);
  if (E.cfg.captions !== false && shot.captions !== false && !shot.endcard) H.captions(mg, t, shot);
  const fo = E.cfg.fadeOut ?? 0, fi = E.cfg.fadeIn ?? 0, dur = window.DURATION, fade = Math.max(fi > 0 ? 1 - t / fi : 0, fo > 0 ? 1 - (dur - t) / fo : 0);
  if (fade > 0) { mg.fillStyle = `rgba(0,0,0,${clamp(fade)})`; mg.fillRect(0, 0, E.W, E.H); }
  if (q.has('debug')) { mg.fillStyle = 'rgba(0,0,0,.6)'; mg.fillRect(0, E.H - 60, E.W, 60); text(mg, `${shot.id}  ${t.toFixed(2)}s  ${(shot.line || '').slice(0, 44)}`, 20, E.H - 30, { size: 26, color: '#fff', align: 'left', weight: 800 }); }
  mg.setTransform(1, 0, 0, 1, 0, 0);
};
boot().catch(e => { window.BOOT_ERROR = e.message + '\n' + e.stack; console.log('BOOT ERROR', e.message); });
