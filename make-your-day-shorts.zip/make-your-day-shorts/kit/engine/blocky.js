// engine/blocky.js — boîte à outils Three.js pour mondes 3D à blocs (matières lisses, ciels pastel, personnages cubiques).
// 1 unité = 1 mètre. Un personnage fait ~1,9 m et regarde vers +z.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { E, rng, ease, clamp, lerp, key, shake } from './core.js';
export { THREE };

let R = null;
export function getRenderer(canvas) {
  if (R) return R;
  R = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true, alpha: false });
  R.setPixelRatio(1); R.setSize(canvas.width, canvas.height, false);
  R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFSoftShadowMap;
  R.toneMapping = THREE.NeutralToneMapping; R.toneMappingExposure = 1.0; R.outputColorSpace = THREE.SRGBColorSpace;
  return R;
}
const C = c => new THREE.Color(c);

// ---------- ciels (dégradé + brouillard + lumière) ----------
export const SKIES = {
  sunset: { stops: ['#5d5bd0', '#c985d8', '#ffb5a0', '#ffd9a8'], fog: '#f0a8b8', sun: '#fff1d6', sunI: 2.6, hemi: ['#ffd7e8', '#9a7aa8'], amb: 0.95, sunPos: [-30, 40, 24] },
  day:    { stops: ['#2f86e6', '#7fbcf5', '#bfe3ff'], fog: '#cfe7ff', sun: '#ffffff', sunI: 2.8, hemi: ['#e6f3ff', '#8aa28a'], amb: 1.0, sunPos: [20, 50, 25] },
  dawn:   { stops: ['#3b3a90', '#e58fb8', '#ffcf9a'], fog: '#f3b9b0', sun: '#ffe2bd', sunI: 2.2, hemi: ['#ffdcd0', '#7f6a90'], amb: 0.9, sunPos: [30, 18, 30] },
  night:  { stops: ['#03041a', '#14104a', '#2a1a66'], fog: '#0d0b30', sun: '#7e8cff', sunI: 0.9, hemi: ['#4a4a9a', '#0a0a1a'], amb: 0.7, sunPos: [-20, 40, 10] },
  neon:   { stops: ['#4a10a8', '#b81ca8', '#ff4a9a'], fog: '#8a2a9a', sun: '#ffd0f0', sunI: 2.0, hemi: ['#ffb0e8', '#5a2a8a'], amb: 0.95, sunPos: [-20, 30, 20] },
  space:  { stops: ['#000008', '#050a3a', '#0b2a8a'], fog: '#050a30', sun: '#ffffff', sunI: 2.4, hemi: ['#8aa8ff', '#101030'], amb: 0.6, sunPos: [30, 20, 30] },
  void:   { stops: ['#000000', '#05050a'], fog: '#000000', sun: '#ff6a2a', sunI: 0.6, hemi: ['#6a4a3a', '#1a1010'], amb: 0.7, sunPos: [0, 20, 10] },
  flatday:{ stops: ['#1e9cf0', '#5bbcf7', '#9bdcff'], fog: '#bfe6ff', sun: '#ffffff', sunI: 2.2, hemi: ['#ffffff', '#c8d8f0'], amb: 1.25, sunPos: [10, 40, 30] },
  burst:  { stops: ['#8a1fd0', '#c93ad8', '#ff5fb0'], fog: '#b02fc0', sun: '#ffffff', sunI: 1.8, hemi: ['#ffffff', '#d8a0ff'], amb: 1.3, sunPos: [0, 30, 30] },
  teal:   { stops: ['#f6e7b8', '#ffe9c2', '#fff2d8'], fog: '#fff0d0', sun: '#fff6e0', sunI: 2.4, hemi: ['#fff3e0', '#7ac8b8'], amb: 1.0, sunPos: [10, 50, 20] },
};
export function canvasTex(w, h, draw, repeat = null) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); } return t;
}

// stage({ sky:'sunset', fog:[near,far], bloom:0, fov:45, shadows:true, shadowSize:14 })
export function stage(o = {}) {
  const sk = typeof o.sky === 'object' ? o.sky : SKIES[o.sky || 'sunset'] || SKIES.sunset;
  const scene = new THREE.Scene();
  scene.background = canvasTex(4, 256, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); sk.stops.forEach((c, i) => gr.addColorStop(i / (sk.stops.length - 1), c)); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
  if (o.fog !== false) scene.fog = new THREE.Fog(C(o.fogColor || sk.fog), ...(o.fog || [40, 220]));
  const camera = new THREE.PerspectiveCamera(o.fov || 45, E.outW / E.outH, 0.1, 1500);
  scene.add(new THREE.HemisphereLight(C(sk.hemi[0]), C(sk.hemi[1]), o.ambient ?? sk.amb));
  const sun = new THREE.DirectionalLight(C(sk.sun), o.sunI ?? sk.sunI); sun.position.set(...(o.sunPos || sk.sunPos));
  const useShadow = o.shadows !== false; sun.castShadow = useShadow;
  const ss = o.shadowSize || 14; sun.shadow.mapSize.set(1024, 1024);
  Object.assign(sun.shadow.camera, { left: -ss, right: ss, top: ss, bottom: -ss, near: 1, far: 200 }); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);
  let composer = null;
  if (o.bloom) {
    composer = new EffectComposer(R, new THREE.WebGLRenderTarget(E.outW, E.outH, { samples: 2, type: THREE.HalfFloatType }));
    composer.addPass(new RenderPass(scene, camera)); composer.addPass(new UnrealBloomPass(new THREE.Vector2(E.outW, E.outH), o.bloom, 0.5, o.bloomThreshold ?? 0.85)); composer.addPass(new OutputPass());
  }
  return {
    scene, camera, sun, sky: sk,
    add: (...objs) => { objs.forEach(ob => ob && scene.add(ob)); return objs[0]; },
    render: () => (composer ? composer.render() : R.render(scene, camera)),
    dispose: () => { scene.traverse(x => { x.geometry?.dispose(); [].concat(x.material || []).forEach(m => { m.map?.dispose(); m.dispose(); }); }); composer?.renderTarget1?.dispose(); composer?.renderTarget2?.dispose(); },
  };
}

// ---------- matériaux & primitives ----------
const _mats = new Map();
export function mat(color, o = {}) {
  const k = color + JSON.stringify(o); if (_mats.has(k)) return _mats.get(k);
  const m = new THREE.MeshStandardMaterial({ color: C(color), roughness: 0.62, metalness: 0, ...o }); _mats.set(k, m); return m;
}
export const glow = (color, k = 1) => new THREE.MeshBasicMaterial({ color: C(color).multiplyScalar(k) });
const prep = (m, cast = true, recv = true) => { m.castShadow = cast; m.receiveShadow = recv; return m; };
const M_ = m => (typeof m === 'string' ? mat(m) : m);
export const box = (w, h, d, m, x = 0, y = 0, z = 0) => { const o = prep(new THREE.Mesh(new THREE.BoxGeometry(w, h, d), M_(m))); o.position.set(x, y, z); return o; };
export const rbox = (w, h, d, m, x = 0, y = 0, z = 0, r = 0.06) => { const o = prep(new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.2, h / 2.2, d / 2.2)), M_(m))); o.position.set(x, y, z); return o; };
export const cyl = (rt, rb, h, m, x = 0, y = 0, z = 0, seg = 20) => { const o = prep(new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), M_(m))); o.position.set(x, y, z); return o; };
export const sphere = (r, m, x = 0, y = 0, z = 0) => { const o = prep(new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), M_(m))); o.position.set(x, y, z); return o; };
export const plane = (w, h, m, x = 0, y = 0, z = 0) => { const o = prep(new THREE.Mesh(new THREE.PlaneGeometry(w, h), M_(m)), false, true); o.position.set(x, y, z); return o; };
export function ground(w, d, color, y = 0) { const o = plane(w, d, color); o.rotation.x = -Math.PI / 2; o.position.y = y; return o; }
export const group = (...kids) => { const g = new THREE.Group(); kids.flat().forEach(k => k && g.add(k)); return g; };

// ---------- visages (texture canvas) ----------
const FACE_CACHE = new Map();
function faceTex(skin, expr = 'neutral', f = {}) {
  const k = [skin, expr, f.mustache, f.sunglasses, f.glasses, f.brow, f.big, f.blush].join('|'); if (FACE_CACHE.has(k)) return FACE_CACHE.get(k);
  const t = canvasTex(256, 256, (g, W, H) => {
    g.clearRect(0, 0, W, H); g.lineCap = 'round'; g.lineJoin = 'round';
    const ink = '#2a1608', eyeY = f.big ? 120 : 112, ex = f.big ? 70 : 62, dotR = f.big ? 16 : 10;
    if (f.blush) { g.fillStyle = 'rgba(255,110,130,.55)'; g.beginPath(); g.ellipse(W / 2 - ex - 14, eyeY + 46, 22, 14, 0, 0, 7); g.fill(); g.beginPath(); g.ellipse(W / 2 + ex + 14, eyeY + 46, 22, 14, 0, 0, 7); g.fill(); }
    const eye = (cx, r) => { g.fillStyle = '#fff'; g.beginPath(); g.arc(cx, eyeY, r, 0, 7); g.fill(); g.lineWidth = 7; g.strokeStyle = ink; g.stroke(); g.fillStyle = ink; g.beginPath(); g.arc(cx, eyeY + 2, r * 0.38, 0, 7); g.fill(); };
    const dot = (cx) => { g.fillStyle = ink; g.beginPath(); g.arc(cx, eyeY, dotR, 0, 7); g.fill(); };
    const brow = (cx, a, dy = -34, len = 38) => { g.strokeStyle = ink; g.lineWidth = 9; g.beginPath(); g.moveTo(cx - len / 2, eyeY + dy + a); g.lineTo(cx + len / 2, eyeY + dy - a); g.stroke(); };
    const L = W / 2 - ex, Rr = W / 2 + ex;
    if (f.sunglasses) { g.fillStyle = '#0a0a0a'; g.fillRect(L - 36, eyeY - 22, 72, 44); g.fillRect(Rr - 36, eyeY - 22, 72, 44); g.fillRect(W / 2 - 30, eyeY - 8, 60, 10); }
    else if (expr === 'shock') { eye(L, 26); eye(Rr, 26); brow(L, -2, -50); brow(Rr, 2, -50); }
    else if (expr === 'worry') { eye(L, 20); eye(Rr, 20); brow(L, -9); brow(Rr, 9); }
    else if (expr === 'angry') { dot(L); dot(Rr); brow(L, 12, -30); brow(Rr, -12, -30); }
    else if (expr === 'sad') { dot(L); dot(Rr); brow(L, -10, -32); brow(Rr, 10, -32); }
    else if (expr === 'determined') { dot(L); dot(Rr); brow(L, 7, -30); brow(Rr, -7, -30); }
    else if (expr === 'happy' || expr === 'smile') { g.strokeStyle = ink; g.lineWidth = 9; g.beginPath(); g.arc(L, eyeY + 8, 16, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); g.beginPath(); g.arc(Rr, eyeY + 8, 16, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); }
    else { dot(L); dot(Rr); if (f.brow !== false) { brow(L, 0, -30); brow(Rr, 0, -30); } }
    if (f.glasses && !f.sunglasses) { g.strokeStyle = '#222'; g.lineWidth = 6; g.strokeRect(L - 30, eyeY - 24, 60, 48); g.strokeRect(Rr - 30, eyeY - 24, 60, 48); g.beginPath(); g.moveTo(L + 30, eyeY); g.lineTo(Rr - 30, eyeY); g.stroke(); }
    const my = 190; g.strokeStyle = ink; g.fillStyle = ink; g.lineWidth = 9;
    if (expr === 'shock') { g.beginPath(); g.ellipse(W / 2, my + 8, 17, 24, 0, 0, 7); g.fill(); }
    else if (expr === 'worry') { g.beginPath(); g.moveTo(W / 2 - 28, my + 10); for (let i = 0; i <= 6; i++) g.lineTo(W / 2 - 28 + i * 9.3, my + 10 + (i % 2 ? -7 : 7)); g.stroke(); }
    else if (expr === 'smile' || expr === 'happy') { g.beginPath(); g.arc(W / 2, my - 14, 34, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke(); }
    else if (expr === 'angry' || expr === 'sad') { g.beginPath(); g.arc(W / 2, my + 30, 28, 1.15 * Math.PI, 1.85 * Math.PI); g.stroke(); }
    else if (expr === 'determined') { g.beginPath(); g.moveTo(W / 2 - 22, my + 6); g.lineTo(W / 2 + 22, my + 6); g.stroke(); }
    else { g.beginPath(); g.arc(W / 2, my - 10, 22, 0.2 * Math.PI, 0.8 * Math.PI); g.stroke(); }
    if (f.mustache) { g.fillStyle = '#1a1208'; g.beginPath(); g.moveTo(W / 2, my - 40); g.quadraticCurveTo(W / 2 - 50, my - 62, W / 2 - 78, my - 28); g.quadraticCurveTo(W / 2 - 40, my - 34, W / 2, my - 22); g.quadraticCurveTo(W / 2 + 40, my - 34, W / 2 + 78, my - 28); g.quadraticCurveTo(W / 2 + 50, my - 62, W / 2, my - 40); g.fill(); }
  });
  FACE_CACHE.set(k, t); return t;
}

// ---------- personnage à blocs ----------
// outfit = { skin, hair, hairStyle:'short'|'spiky'|'bald'|'cap', shirt, pants, shoes, patches:n, patchColor, accessories:['tophat','mustache','sunglasses','glasses','chain','cane','backpack','cap'], hatColor, number, scale, hoodie }
export function blockFigure(outfit = {}) {
  const o = { skin: '#f0c59a', hair: '#5b3a1e', hairStyle: 'short', shirt: '#7f93b5', pants: '#3b4c6b', shoes: '#2a2a33', patches: 0, patchColor: '#a08a6a', accessories: [], scale: 1, ...outfit };
  const root = new THREE.Group(), body = new THREE.Group(); root.add(body); body.scale.setScalar(o.scale);
  const skin = mat(o.skin, { roughness: 0.7 }), shirt = mat(o.shirt), pants = mat(o.pants), shoe = mat(o.shoes), hairM = mat(o.hair, { roughness: 0.85 });
  const acc = new Set(o.accessories || []);
  // proportions (m)
  const chibi = o.style === 'chibi';
  const LEG = chibi ? 0.42 : 0.72, TORSO = chibi ? 0.55 : 0.74, TW = chibi ? 0.6 : 0.62, TD = chibi ? 0.38 : 0.34, HEAD = chibi ? 0.86 : 0.52, ARM = chibi ? 0.5 : 0.7;
  const mkLimb = (w, h, d, m, ex) => { const pv = new THREE.Group(); const l = rbox(w, h, d, m, 0, -h / 2, 0, 0.07); pv.add(l); if (ex) pv.add(ex(l)); return pv; };
  const legL = mkLimb(chibi ? 0.24 : 0.28, LEG, 0.3, pants), legR = mkLimb(chibi ? 0.24 : 0.28, LEG, 0.3, pants);
  for (const lg of [legL, legR]) { const foot = rbox(0.3, 0.12, 0.38, shoe, 0, -LEG + 0.06, 0.04, 0.05); lg.add(foot); }
  legL.position.set(-0.16, LEG, 0); legR.position.set(0.16, LEG, 0);
  const torso = rbox(TW, TORSO, TD, shirt, 0, LEG + TORSO / 2, 0, 0.08);
  const armL = mkLimb(0.22, ARM, 0.24, shirt), armR = mkLimb(0.22, ARM, 0.24, shirt);
  for (const a of [armL, armR]) { const hand = rbox(0.24, 0.2, 0.26, skin, 0, -ARM + 0.04, 0, 0.06); a.add(hand); }
  armL.position.set(-(TW / 2 + 0.13), LEG + TORSO - 0.08, 0); armR.position.set(TW / 2 + 0.13, LEG + TORSO - 0.08, 0);
  const headPivot = new THREE.Group(); headPivot.position.set(0, LEG + TORSO + 0.02, 0);
  const head = rbox(HEAD, HEAD, HEAD, skin, 0, HEAD / 2, 0, chibi ? 0.3 : 0.09); headPivot.add(head);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(HEAD * 0.96, HEAD * 0.96), new THREE.MeshBasicMaterial({ map: faceTex(o.skin, 'neutral', {}), transparent: true }));
  face.position.set(0, HEAD / 2, HEAD / 2 + 0.003); headPivot.add(face);
  // cheveux / coiffe
  if (o.hairStyle !== 'bald') {
    const top = rbox(HEAD + 0.04, 0.12, HEAD + 0.04, hairM, 0, HEAD + 0.02, 0, 0.05), back = rbox(HEAD + 0.04, HEAD * 0.7, 0.1, hairM, 0, HEAD * 0.62, -HEAD / 2 - 0.0, 0.04), fringe = rbox(HEAD + 0.04, 0.1, 0.1, hairM, 0, HEAD - 0.04, HEAD / 2 + 0.0, 0.04);
    headPivot.add(top, back, fringe);
    if (o.hairStyle === 'spiky') for (let i = 0; i < 5; i++) headPivot.add(rbox(0.1, 0.16, 0.1, hairM, -0.2 + i * 0.1, HEAD + 0.13 + (i % 2) * 0.04, (i % 3 - 1) * 0.06, 0.03));
  }
  if (acc.has('tophat')) { const hc = mat(o.hatColor || '#f4f1ea'); headPivot.add(cyl(0.34, 0.34, 0.03, hc, 0, HEAD + 0.03, 0, 24), cyl(0.2, 0.2, 0.34, hc, 0, HEAD + 0.2, 0, 24), cyl(0.205, 0.205, 0.05, mat('#222'), 0, HEAD + 0.1, 0, 24)); }
  if (acc.has('cap')) { const hc = mat(o.hatColor || '#c0392b'); const dome = new THREE.Mesh(new THREE.SphereGeometry(0.3, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), hc); dome.position.y = HEAD - 0.02; dome.castShadow = true; const brim = rbox(0.4, 0.04, 0.26, hc, 0, HEAD + 0.02, HEAD / 2 + 0.1, 0.02); headPivot.add(dome, brim); }
  if (acc.has('chain')) { const ch = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 24), mat('#f2c230', { metalness: 0.6, roughness: 0.3 })); ch.position.set(0, LEG + TORSO - 0.1, TD / 2 - 0.02); ch.rotation.x = Math.PI / 2.2; body.add(ch); body.add(sphere(0.06, mat('#f2c230', { metalness: 0.6, roughness: 0.3 }), 0, LEG + TORSO - 0.3, TD / 2 + 0.06)); }
  if (acc.has('backpack')) body.add(rbox(0.46, 0.55, 0.22, mat(o.backpackColor || '#7a3fb5'), 0, LEG + TORSO / 2 + 0.05, -TD / 2 - 0.12, 0.06));
  if (acc.has('cane')) { const cane = group(cyl(0.025, 0.025, 1.0, mat('#222'), 0, -0.45, 0.12, 8), sphere(0.05, mat('#f2c230'), 0, 0.05, 0.12)); cane.position.set(0, -ARM + 0.1, 0.0); armR.add(cane); }
  // pièces rapiécées (carrés) sur torse et jambes
  const pr = rng(7); const pm = mat(o.patchColor, { roughness: 0.9 });
  for (let i = 0; i < o.patches; i++) { const onLeg = i % 3 === 2; const s = 0.1 + pr() * 0.06; if (onLeg) { const lg = i % 2 ? legL : legR; lg.add(box(s, s, 0.012, pm, (pr() - 0.5) * 0.1, -0.2 - pr() * 0.3, 0.152)); } else torso.add(box(s, s, 0.012, pm, (pr() - 0.5) * 0.4, (pr() - 0.5) * 0.45, TD / 2 + 0.006)); }
  if (o.number) { const nt = canvasTex(128, 128, (g, w, h) => { g.fillStyle = '#fff'; g.font = '900 96px Montserrat'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(o.number), w / 2, h / 2 + 6); }); const nm = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.3), new THREE.MeshBasicMaterial({ map: nt, transparent: true })); nm.position.set(0, 0, TD / 2 + 0.004); torso.add(nm); }
  if (o.hoodie) { torso.add(rbox(TW * 0.62, 0.17, 0.05, mat(o.hoodiePocket || o.shirt), 0, -0.12, TD / 2 + 0.02, 0.04)); body.add(rbox(TW * 0.95, 0.18, TD + 0.1, shirt, 0, LEG + TORSO + 0.0, -0.02, 0.07)); }
  body.add(legL, legR, torso, armL, armR, headPivot);
  const fflags = { mustache: acc.has('mustache'), sunglasses: acc.has('sunglasses'), glasses: acc.has('glasses'), big: chibi, blush: chibi || !!o.blush };
  const fig = { root, body, parts: { legL, legR, armL, armR, headPivot, torso }, outfit: o };
  fig.setExpr = (e) => { face.material.map = faceTex(o.skin, e, fflags); face.material.needsUpdate = true; };
  fig.setExpr('neutral');
  // animation : angles en radians, rotation.x négative = bras/jambe vers l'avant
  fig.animate = (name = 'idle', t = 0, k = 1) => {
    const P = fig.parts, s = Math.sin, set = (p, x = 0, z = 0) => { P[p].rotation.x = x; P[p].rotation.z = z; };
    let by = 0, hx = 0, hz = 0, hy = 0, tx = 0;
    switch (name) {
      case 'walk': case 'run': { const f = name === 'run' ? 11 : 6.5, a = name === 'run' ? 0.95 : 0.55; set('legL', s(t * f) * a); set('legR', -s(t * f) * a); set('armL', -s(t * f) * a * 0.9); set('armR', s(t * f) * a * 0.9); by = Math.abs(s(t * f)) * (name === 'run' ? 0.12 : 0.05); tx = name === 'run' ? -0.18 : 0; break; }
      case 'cheer': { set('legL', 0, -0.1); set('legR', 0, 0.1); set('armL', -2.9 + s(t * 10) * 0.25, -0.2); set('armR', -2.9 - s(t * 10) * 0.25, 0.2); by = Math.abs(s(t * 8)) * 0.25; hx = -0.15; break; }
      case 'shock': { set('legL', 0, -0.06); set('legR', 0, 0.06); set('armL', -0.4, -0.7 + s(t * 30) * 0.03); set('armR', -0.4, 0.7 - s(t * 30) * 0.03); hx = -0.2; tx = -0.12; by = Math.max(0, s(t * 40)) * 0.015; break; }
      case 'wave': { set('legL'); set('legR'); set('armL', 0.05, -0.08); set('armR', -2.7, 0.25 + s(t * 9) * 0.35); hz = 0.08; break; }
      case 'point': { set('legL', 0, -0.05); set('legR', 0, 0.05); set('armL', 0.05, -0.08); set('armR', -1.57 - 0.05 * s(t * 3)); break; }
      case 'pointup': { set('legL'); set('legR'); set('armL', 0.05, -0.08); set('armR', -2.95); hx = -0.35; break; }
      case 'climb': { set('legL', -s(t * 5) * 0.8 - 0.4); set('legR', s(t * 5) * 0.8 - 0.4); set('armL', -2.6 - s(t * 5) * 0.5); set('armR', -2.6 + s(t * 5) * 0.5); by = s(t * 5) * 0.03; hx = -0.3; break; }
      case 'fall': { set('legL', -0.4 + s(t * 12) * 0.4); set('legR', -0.4 - s(t * 12) * 0.4); set('armL', -2.6 + s(t * 14) * 0.5, -0.5); set('armR', -2.6 - s(t * 14) * 0.5, 0.5); hx = -0.3; break; }
      case 'sit': { set('legL', -1.57); set('legR', -1.57); set('armL', -0.5); set('armR', -0.5); by = -0.38; break; }
      case 'crouch': { set('legL', -1.1); set('legR', -1.1); set('armL', -0.9); set('armR', -0.9); by = -0.32; tx = 0.4; break; }
      case 'lookup': { set('legL'); set('legR'); set('armL', 0, -0.05); set('armR', 0, 0.05); hx = -0.55; by = s(t * 1.6) * 0.008; break; }
      case 'arms': { set('legL'); set('legR'); set('armL', -1.4, -0.1); set('armR', -1.4, 0.1); break; }   // bras croisés/devant
      default: { set('legL'); set('legR'); set('armL', s(t * 1.7) * 0.05, -0.06); set('armR', -s(t * 1.7) * 0.05, 0.06); by = s(t * 2.2) * 0.008; hy = s(t * 0.7) * 0.12; }
    }
    P.headPivot.rotation.set(hx, hy, hz); P.torso.rotation.x = tx; body.position.y = by;
    P.armL.rotation.x += 0; return fig;
  };
  fig.headPos = () => { const v = new THREE.Vector3(); P_head.getWorldPosition(v); return v; };
  const P_head = head;
  return fig;
}

// ---------- bâtiments ----------
const _winTex = new Map();
function winTexture(kind, rx, ry) {
  const k = kind; if (!_winTex.has(k)) _winTex.set(k, canvasTex(64, 64, (g, w, h) => {
    const pal = { toonBlue: ['#2c6fe0', '#ffd84a', '#1c3f9a'], toonPink: ['#ff3fa4', '#ffd84a', '#b81f78'], toonYellow: ['#ffc21f', '#fff3b0', '#c28a0a'], toonPurple: ['#7a3fd0', '#ffd84a', '#4a1f90'], toonOrange: ['#ff7a1a', '#ffe07a', '#b8480a'], glass: ['#2f6fe0', '#8fd0ff', '#1d4ab0'], warm: ['#d9a86a', '#ffe9b0', '#9a6a3a'], pink: ['#d79ab8', '#ffe3f0', '#9a5a7a'], gold: ['#e0b030', '#fff0a0', '#a07810'], night: ['#1a1f4a', '#ffd470', '#0c0e2a'] }[kind] || ['#2f6fe0', '#8fd0ff', '#1d4ab0'];
    g.fillStyle = pal[0]; g.fillRect(0, 0, w, h); g.fillStyle = pal[2]; g.fillRect(0, 0, w, 3); g.fillRect(0, 0, 3, h);
    const gr = g.createLinearGradient(0, 8, 0, 56); gr.addColorStop(0, pal[1]); gr.addColorStop(1, pal[0]); g.fillStyle = gr; g.fillRect(8, 8, 22, 22); g.fillRect(34, 8, 22, 22); g.fillRect(8, 34, 22, 22); g.fillRect(34, 34, 22, 22);
  }));
  const t = _winTex.get(k).clone(); t.needsUpdate = true; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); return t;
}
// tower(w, h, d, { kind:'glass'|'warm'|'pink'|'gold'|'night', floor:3.4, bands:0, cap:true, lit:false })
export function tower(w, h, d, o = {}) {
  const { kind = 'glass', floor = 3.4, bands = 0, cap = true, trim = '#d8dde8', emissive = 0 } = o;
  const mk = (rx) => new THREE.MeshStandardMaterial({ map: winTexture(kind, rx, Math.max(1, Math.round(h / floor))), roughness: 0.35, metalness: 0.1, emissive: emissive ? C('#ffffff') : C('#000000'), emissiveMap: emissive ? winTexture(kind, rx, Math.max(1, Math.round(h / floor))) : null, emissiveIntensity: emissive });
  const sx = mk(Math.max(1, Math.round(d / 2.6))), sz = mk(Math.max(1, Math.round(w / 2.6))), top = mat(trim);
  const m = prep(new THREE.Mesh(new THREE.BoxGeometry(w, h, d), [sx, sx, top, top, sz, sz])); m.position.y = h / 2;
  const g = group(m);
  if (cap) g.add(box(w + 0.3, 0.5, d + 0.3, trim, 0, h + 0.25, 0));
  for (let i = 1; i <= bands; i++) g.add(box(w + 0.2, 0.45, d + 0.2, '#f2c230', 0, (h * i) / (bands + 1), 0));
  g.userData.h = h; return g;
}
export function shack(o = {}) {
  const { w = 3, h = 2.4, d = 2.6, wood = '#8a5a34', door = '#4a2c18', roof = '#6a4426', num = null } = o;
  const g = group(box(w, h, d, wood, 0, h / 2, 0), box(w + 0.4, 0.18, d + 0.4, roof, 0, h + 0.09, 0), box(0.9, 1.6, 0.06, door, 0, 0.8, d / 2 + 0.02));
  for (let i = -2; i <= 2; i++) g.add(box(0.05, h, 0.04, '#6a4426', i * (w / 5), h / 2, d / 2 + 0.03));
  if (num !== null) { const t = canvasTex(256, 128, (c, W, H) => { c.fillStyle = '#e9d8a8'; c.fillRect(0, 0, W, H); c.fillStyle = '#222'; c.font = '900 74px Montserrat'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(String(num), W / 2, H / 2 + 4); }); g.add(plane(0.9, 0.45, new THREE.MeshBasicMaterial({ map: t }), 0, h * 0.78, d / 2 + 0.05)); }
  return g;
}
export function house(o = {}) {
  const { w = 3, h = 2.4, d = 3, wall = '#f3efe6', roof = '#e08a3a', door = '#6a3b22', win = '#8ecbf0' } = o;
  const g = group(rbox(w, h, d, wall, 0, h / 2, 0, 0.04));
  const r = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.78, 1.3, 4), mat(roof)); r.rotation.y = Math.PI / 4; r.position.y = h + 0.65; r.castShadow = true; g.add(r);
  g.add(box(0.7, 1.4, 0.06, door, 0, 0.7, d / 2 + 0.02), box(0.7, 0.7, 0.06, win, -w * 0.3, h * 0.6, d / 2 + 0.02), box(0.7, 0.7, 0.06, win, w * 0.3, h * 0.6, d / 2 + 0.02)); return g;
}
export function goldDome(r = 3, o = {}) {
  const gold = mat('#f2b82c', { metalness: 0.5, roughness: 0.28 }), wall = mat(o.wall || '#f4e9cf');
  const g = group();
  g.add(box(r * 2.4, r * 1.1, r * 2.4, wall, 0, r * 0.55, 0));
  const dome = new THREE.Mesh(new THREE.SphereGeometry(r, 28, 16, 0, Math.PI * 2, 0, Math.PI / 2), gold); dome.position.y = r * 1.1; dome.castShadow = true; g.add(dome);
  g.add(cyl(0.05 * r, 0.05 * r, r * 0.9, gold, 0, r * 2.15, 0, 8), sphere(0.12 * r, gold, 0, r * 2.6, 0));
  for (const [x, z] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { g.add(cyl(0.16 * r, 0.16 * r, r * 1.9, wall, x * r * 1.3, r * 0.95, z * r * 1.3, 12)); const c = new THREE.Mesh(new THREE.ConeGeometry(0.22 * r, 0.7 * r, 12), gold); c.position.set(x * r * 1.3, r * 2.25, z * r * 1.3); c.castShadow = true; g.add(c); }
  for (let i = -2; i <= 2; i++) g.add(box(r * 0.18, r * 0.3, 0.05, '#ffd86a', i * r * 0.42, r * 0.55, r * 1.21));
  return g;
}
export function cloud(s = 1, color = '#ffd6ea') {
  const g = group(), r = rng(Math.floor(s * 100) + 5), m = mat(color, { roughness: 1, emissive: color, emissiveIntensity: 0.55 });
  for (let i = 0; i < 6; i++) { const b = sphere((0.8 + r() * 0.7) * s, m, (i - 2.5) * 0.9 * s, (r() - 0.3) * 0.5 * s, (r() - 0.5) * 0.9 * s); b.castShadow = false; g.add(b); } return g;
}
export function tree(s = 1, leaf = '#3f9a3a') { return group(cyl(0.12 * s, 0.16 * s, 1.2 * s, '#7a5230', 0, 0.6 * s, 0, 8), rbox(1.2 * s, 1.2 * s, 1.2 * s, leaf, 0, 1.6 * s, 0, 0.25 * s)); }
export function lamp(h = 4, color = '#ffe9a8') { return group(cyl(0.06, 0.08, h, '#2a2a2a', 0, h / 2, 0, 8), box(0.5, 0.08, 0.08, '#2a2a2a', 0.2, h, 0), sphere(0.16, glow(color), 0.42, h - 0.12, 0)); }
export function tire(r = 0.45) { const t = new THREE.Mesh(new THREE.TorusGeometry(r, r * 0.38, 10, 20), mat('#1d1d22', { roughness: 0.9 })); t.rotation.x = Math.PI / 2; t.position.y = r * 0.38; t.castShadow = true; return t; }

// foule de petits personnages (instancié) : crowd({ n, w, d, y, colors, seed, scale })
export function crowd(o = {}) {
  const { n = 60, w = 20, d = 20, y = 0, seed = 5, scale = 1, colors = ['#e74c3c', '#3498db', '#f1c40f', '#9b59b6', '#2ecc71', '#e67e22', '#ecf0f1', '#ff6fa8'], skins = ['#f0c59a', '#d9a273', '#a8704a', '#fbd9bd'], x = 0, z = 0, hole = 0 } = o;
  const r = rng(seed), bodyG = new RoundedBoxGeometry(0.46, 0.9, 0.3, 2, 0.05), headG = new RoundedBoxGeometry(0.34, 0.34, 0.34, 2, 0.05);
  const bodies = new THREE.InstancedMesh(bodyG, mat('#ffffff'), n), heads = new THREE.InstancedMesh(headG, mat('#ffffff'), n);
  const m4 = new THREE.Matrix4(), col = new THREE.Color(), q = new THREE.Quaternion(), sc = new THREE.Vector3(scale, scale, scale), e = new THREE.Euler();
  for (let i = 0; i < n; i++) {
    let px, pz; do { px = (r() - 0.5) * w; pz = (r() - 0.5) * d; } while (hole && Math.hypot(px, pz) < hole);
    q.setFromEuler(e.set(0, r() * Math.PI * 2, 0));
    m4.compose(new THREE.Vector3(x + px, y + 0.45 * scale + 0.45 * scale, z + pz), q, sc); bodies.setMatrixAt(i, m4); bodies.setColorAt(i, col.set(colors[Math.floor(r() * colors.length)]));
    m4.compose(new THREE.Vector3(x + px, y + 1.1 * scale + 0.1 * scale, z + pz), q, sc); heads.setMatrixAt(i, m4); heads.setColorAt(i, col.set(skins[Math.floor(r() * skins.length)]));
  }
  bodies.castShadow = heads.castShadow = true; return group(bodies, heads);
}

// ---------- caméras ----------
// cam = { type:'push'|'orbit'|'dolly'|'face', ... }  (t = secondes depuis le début du plan, dur = durée du plan)
export function applyCamera(camera, cam = {}, t, dur, ctx = {}) {
  const k = ease[cam.ease || 'inOut'] ? ease[cam.ease || 'inOut'](clamp(t / dur)) : clamp(t / dur);
  const v3 = a => new THREE.Vector3(...a), at = (a, b) => (Array.isArray(a) ? a.map((x, i) => lerp(x, b[i], k)) : lerp(a, b, k));
  let pos, look, fov = cam.fov || 45, roll = cam.roll || 0;
  switch (cam.type) {
    case 'orbit': { const tg = cam.target || [0, 1.5, 0], a = lerp(cam.from ?? -0.6, cam.to ?? 0.4, k), r = Array.isArray(cam.radius) ? lerp(cam.radius[0], cam.radius[1], k) : cam.radius ?? 8, h = Array.isArray(cam.height) ? lerp(cam.height[0], cam.height[1], k) : cam.height ?? 2.5; pos = [tg[0] + Math.sin(a) * r, h, tg[2] + Math.cos(a) * r]; look = tg; break; }
    case 'dolly': { const v = key(t, cam.keys, ease[cam.ease || 'inOut']); pos = v.pos; look = v.look; fov = v.fov || fov; roll = v.roll ?? roll; break; }
    case 'face': { const a = ctx.actors?.[cam.actor]; const hp = a ? a.fig.headPos() : new THREE.Vector3(0, 1.7, 0); const dist = lerp(cam.dist?.[0] ?? cam.dist ?? 1.5, cam.dist?.[1] ?? cam.dist ?? 1.5, k), ang = (cam.angle || 0) + (cam.drift || 0) * k, rot = a ? a.holder.rotation.y : 0; pos = [hp.x + Math.sin(rot + ang) * dist, hp.y + (cam.up ?? 0.05), hp.z + Math.cos(rot + ang) * dist]; look = [hp.x, hp.y + (cam.lookUp ?? -0.02), hp.z]; fov = cam.fov || 38; break; }
    default: { /* push : de from vers to */ const from = cam.from || cam.pos || [0, 2, 8], to = cam.to || from; pos = at(from, to); look = cam.lookTo ? at(cam.look || [0, 1.5, 0], cam.lookTo) : cam.look || [0, 1.5, 0]; }
  }
  if (cam.shake) { const s = shake(t, cam.shake, cam.shakeFreq || 9); pos = [pos[0] + s[0], pos[1] + s[1], pos[2] + s[2]]; }
  camera.position.set(...pos); camera.up.set(Math.sin(roll), Math.cos(roll), 0); camera.lookAt(...look);
  if (camera.fov !== fov) { camera.fov = fov; camera.updateProjectionMatrix(); }
}
// projection 3D -> coordonnées logiques 1080x1920 (pour accrocher du texte/HUD à un objet)
export function project(camera, p) { const v = new THREE.Vector3(...p).project(camera); return { x: (v.x * 0.5 + 0.5) * E.W, y: (-v.y * 0.5 + 0.5) * E.H, z: v.z, visible: v.z < 1 && Math.abs(v.x) < 1.2 && Math.abs(v.y) < 1.2 }; }

// ---------- panneaux, véhicules, animaux ----------
// sign('CENTRE DE LA MALCHANCE', 6, 1.2, { bg:'#ffffff', color:'#0d8a80', glow:false })
export function sign(str, w = 4, h = 1, o = {}) {
  const { bg = '#ffffff', color = '#111', size = 0.62, glow: gl = false, border = null } = o, px = 512, py = Math.max(64, Math.round(512 * h / w));
  const tex = canvasTex(px, py, (g, W, Hh) => { g.fillStyle = bg; g.fillRect(0, 0, W, Hh); if (border) { g.strokeStyle = border; g.lineWidth = 14; g.strokeRect(7, 7, W - 14, Hh - 14); } g.fillStyle = color; g.textAlign = 'center'; g.textBaseline = 'middle'; let fs = Hh * size; g.font = `900 ${fs}px Montserrat`; const tw = g.measureText(str).width; if (tw > W * 0.92) { fs *= (W * 0.92) / tw; g.font = `900 ${fs}px Montserrat`; } g.fillText(str, W / 2, Hh / 2 + fs * 0.04); });
  return plane(w, h, gl ? new THREE.MeshBasicMaterial({ map: tex }) : new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 }));
}
export function bus(o = {}) {
  const { color = '#2f8f3a', length = 9, label = 'LIGNE 13' } = o, g = group(rbox(2.6, 2.7, length, color, 0, 1.8, 0, 0.15), box(2.62, 0.9, length - 0.8, '#bfe6ff', 0, 2.4, 0), box(2.64, 0.12, length, '#f2f2f2', 0, 1.2, 0));
  for (const sx of [-1, 1]) for (const z of [-length * 0.32, length * 0.32]) { const w = cyl(0.55, 0.55, 0.4, '#1d1d22', sx * 1.3, 0.55, z, 20); w.rotation.z = Math.PI / 2; g.add(w); }
  const sg = sign(label, 1.6, 0.4, { bg: '#111', color: '#ffd23f', glow: true }); sg.position.set(0, 3.3, length / 2 + 0.02); g.add(sg); return g;
}
export function poodle(o = {}) {
  const c = o.color || '#ffb3d1', m = mat(c, { roughness: 0.9 }), g = group(sphere(0.55, m, 0, 0.7, 0), sphere(0.38, m, 0, 1.25, 0.45), sphere(0.2, m, -0.32, 1.3, 0.4), sphere(0.2, m, 0.32, 1.3, 0.4), sphere(0.17, m, 0, 0.8, -0.62), box(0.09, 0.09, 0.09, '#222', -0.13, 1.33, 0.78), box(0.09, 0.09, 0.09, '#222', 0.13, 1.33, 0.78), sphere(0.06, '#222', 0, 1.22, 0.82));
  for (const [x, z] of [[-0.25, 0.3], [0.25, 0.3], [-0.25, -0.3], [0.25, -0.3]]) g.add(cyl(0.09, 0.09, 0.35, m, x, 0.18, z, 8)); return g;
}
// toonify(objet, { outline: 0.04, ink: '#1a1020' }) : matériaux à aplats (3 niveaux) + contour noir épais (coque inversée) -> rendu « 2D adapté en 3D »
let _grad = null;
export function toonify(root, o = {}) {
  const { outline = 0.04, ink = '#1a1020', maxSize = 14, steps = 4 } = o;
  if (!_grad) { const d = new Uint8Array(steps * 4); for (let i = 0; i < steps; i++) { const v = Math.round(255 * (0.58 + 0.42 * (i / (steps - 1)))); d.set([v, v, v, 255], i * 4); } _grad = new THREE.DataTexture(d, steps, 1, THREE.RGBAFormat); _grad.minFilter = _grad.magFilter = THREE.NearestFilter; _grad.needsUpdate = true; }
  const inkM = new THREE.MeshBasicMaterial({ color: C(ink), side: THREE.BackSide }), conv = new Map(), list = [];
  root.traverse(ob => { if (ob.isMesh && !ob.isInstancedMesh && !ob.userData.noOutline) list.push(ob); });
  for (const m of list) {
    const mats = [].concat(m.material).map(mm => { if (!mm.isMeshStandardMaterial) return mm; if (!conv.has(mm)) conv.set(mm, new THREE.MeshToonMaterial({ color: mm.color, map: mm.map, gradientMap: _grad, emissive: mm.emissive, emissiveIntensity: mm.emissiveIntensity, emissiveMap: mm.emissiveMap, transparent: mm.transparent, opacity: mm.opacity })); return conv.get(mm); });
    m.material = Array.isArray(m.material) ? mats : mats[0];
    const gm = m.geometry; if (!gm || gm.type === 'PlaneGeometry' || gm.type === 'BufferGeometry') continue; gm.computeBoundingBox(); const sz = new THREE.Vector3(); gm.boundingBox.getSize(sz);
    const ws = new THREE.Vector3(); m.getWorldScale(ws); const dx = sz.x * ws.x, dy = sz.y * ws.y, dz = sz.z * ws.z; if (Math.max(dx, dy, dz) > maxSize || Math.min(dx, dy, dz) < 0.02) continue;
    const ol = new THREE.Mesh(gm, inkM); ol.position.copy(m.position); ol.quaternion.copy(m.quaternion); ol.scale.set(m.scale.x * (1 + 2 * outline / dx), m.scale.y * (1 + 2 * outline / dy), m.scale.z * (1 + 2 * outline / dz)); ol.userData.noOutline = true; m.parent.add(ol);
  }
  return root;
}
