// engine/hud.js — calques 2D par-dessus la 3D (canevas logique 1080x1920).
import { E, ease, clamp, lerp, prog, text, rr, measure, alpha } from './core.js';

export const STYLE = {
  yellow: '#E3FC2B', cyan: '#6EE7FF', white: '#FFFFFF', red: '#FF4D4D', gold: '#FFD23F', ink: '#000000',
  capY: 0.635,            // position verticale des sous-titres (fraction de la hauteur)
  capSize: 98,            // taille de base (mesuré : lettre ~72 px de haut sur les références)
  capStroke: 16,          // épaisseur du contour noir
};
const norm = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w']/g, '');
const SMALL = new Set(['et', 'le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'a', 'à', 'en', 'au', 'je', 'tu', 'il', 'on', 'ne', 'pas', 'que', 'qui', 'ce', 'se', 'y', 'mais', 'ou', 'si', 'sa', 'son', 'ses', 'mon', 'ma', 'mes', "j'ai", "j'", "l'", "d'", "c'est", 'est']);

// ---------- sous-titres : un seul mot à l'écran, synchronisé sur la voix ----------
export function currentWord(t) {
  const W = E.words; if (!W.length) return null;
  let lo = 0, hi = W.length - 1, idx = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (W[m].start <= t + 0.02) { idx = m; lo = m + 1; } else hi = m - 1; }
  if (idx < 0) return null;
  const w = W[idx], next = W[idx + 1];
  const holdEnd = Math.min(w.end + 0.28, next ? next.start : 1e9);       // le mot reste jusqu'au suivant (max +0,28 s)
  return t <= Math.max(holdEnd, w.start + 0.18) ? { w, idx, age: t - w.start } : null;
}
// emphase : mot-clé = liste cfg.emph, emph du plan, ou chiffres (cfg.autoEmph=true ajoute les mots de 9 lettres et +)
export function isEmph(word, shot) {
  const n = norm(word), list = [...(E.cfg.emph || []), ...(shot?.emph || [])].map(norm);
  if (list.some(k => n === k || (k.length > 3 && n.startsWith(k)))) return true;
  if (/\d/.test(n)) return true;
  return E.cfg.autoEmph === true && n.length >= 9;
}
export function captions(g, t, shot) {
  const preset = E.cfg.captionPreset || 'yellow';
  const cs = { ...STYLE, ...(preset === 'gold' ? { capSize: 70, capStroke: 12, capY: 0.5 } : {}), ...(E.cfg.captionStyle || {}) };
  const cw = currentWord(t); if (!cw) return;
  let s = cw.w.word.replace(/^[«"“(\[]+|[»"”)\].,;:!?…]+$/g, '').trim(); if (!s) return;
  const em = isEmph(s, shot), small = SMALL.has(s.toLowerCase());
  const label = (preset === 'gold' || em) ? s.toUpperCase() : s.toLowerCase();
  const pop = ease.outBack(cw.age / 0.13), sc = (em ? 1.45 : small ? 0.86 : 1) * (0.78 + 0.22 * pop);
  let size = cs.capSize * sc; const maxW = E.W * 0.9, mw = measure(g, label, size);
  if (mw > maxW) size *= maxW / mw;
  const y = E.H * (shot?.capY ?? cs.capY);
  if (preset === 'gold') {
    g.save(); g.font = `900 ${size}px "Montserrat"`; const gr = g.createLinearGradient(0, y - size * 0.5, 0, y + size * 0.5); gr.addColorStop(0, em ? '#fff7c2' : '#ffe566'); gr.addColorStop(1, em ? '#ffc23a' : '#ff9d1a');
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.lineWidth = cs.capStroke * (size / cs.capSize); g.strokeStyle = '#3a1800'; g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 10; g.shadowOffsetY = 4; g.strokeText(label, E.W / 2, y); g.shadowColor = 'transparent'; g.fillStyle = gr; g.fillText(label, E.W / 2, y); g.restore(); return;
  }
  const col = em ? (shot?.emphColor || (/\d/.test(label) ? cs.gold : cs.cyan)) : cs.yellow;
  text(g, label, E.W / 2, y, { size, color: col, stroke: cs.capStroke * (size / cs.capSize), shadow: 12, weight: 900 });
}

// ---------- badge PARTIE N ----------
export function badge(g, label) {
  g.save(); g.font = '900 30px "Montserrat"'; const w = g.measureText(label).width + 34, x = 34, y = 74, h = 50;
  rr(g, x, y, w, h, 10); g.fillStyle = 'rgba(12,16,10,.88)'; g.fill(); g.lineWidth = 4; g.strokeStyle = STYLE.yellow; g.stroke();
  text(g, label, x + w / 2, y + h / 2 + 2, { size: 30, color: STYLE.yellow, weight: 900 }); g.restore();
}
// ---------- jauge ÉTAGE : barre verticale à gauche + encadré chiffré ----------
export function gauge(g, value, o = {}) {
  const { max = 10000, label = 'ÉTAGE', text: txt = null, y0 = 430, y1 = 1230 } = o;
  const k = value === null ? 1 : clamp(Math.log10(1 + Math.max(0, value)) / Math.log10(1 + max));
  g.save(); rr(g, 44, y0, 10, y1 - y0, 5); g.fillStyle = 'rgba(0,0,0,.45)'; g.fill();
  const yy = y1 - (y1 - y0) * k; rr(g, 44, yy, 10, y1 - yy, 5); g.fillStyle = STYLE.yellow; g.fill();
  const val = txt ?? (value < 0 ? `${Math.round(value)}` : String(Math.round(value))), bw = 118, bh = 74, bx = 64, by = clamp(yy - bh / 2, y0 - 20, y1 - bh);
  rr(g, bx, by, bw, bh, 10); g.fillStyle = 'rgba(10,10,14,.9)'; g.fill(); g.lineWidth = 3; g.strokeStyle = STYLE.yellow; g.stroke();
  text(g, label, bx + bw / 2, by + 20, { size: 16, color: '#fff', weight: 800 });
  text(g, val, bx + bw / 2, by + 50, { size: val.length > 5 ? 26 : 36, color: STYLE.yellow, weight: 900 });
  g.restore();
}
// ---------- éléments diégétiques ----------
// étiquette de lieu/personnage en capitales, accrochée à une position écran
export function tag(g, str, x, y, o = {}) { const { color = STYLE.yellow, size = 54, a = 1, sc = 1 } = o; g.save(); g.translate(x, y); g.rotate(o.rot ?? -0.04); text(g, str.toUpperCase(), 0, 0, { size: size * sc, color, stroke: 12 * sc, shadow: 8, alpha: a, weight: 900 }); g.restore(); }
export function bang(g, x, y, t = 0) { const s = 1 + 0.12 * Math.sin(t * 16); g.save(); g.translate(x, y); g.scale(s, s); text(g, '!', 0, 0, { size: 120, color: STYLE.yellow, stroke: 14, weight: 900 }); g.restore(); }
export function floatText(g, str, x, y, k, o = {}) { text(g, str, x, y - 120 * ease.out(k), { size: o.size || 64, color: o.color || STYLE.yellow, stroke: 12, alpha: 1 - ease.in(prog(k, 0.6, 1)), weight: 900 }); }
// panneau d'interface (ex. SCANNING.. avec barre, ou NOUVEAU PROPRIÉTAIRE IDENTIFIÉ)
export function panel(g, o, k = 1) {
  const { title = 'SCANNING..', sub = '', progress = null, x = E.W / 2, y = E.H * 0.3, w = 760, h = 230, accent = STYLE.yellow, bg = '#0d2a6a' } = o;
  const s = ease.outBack(k); g.save(); g.translate(x, y); g.scale(s, s);
  rr(g, -w / 2, -h / 2, w, h, 24); g.fillStyle = bg; g.fill(); g.lineWidth = 8; g.strokeStyle = accent; g.stroke();
  text(g, title, 0, sub || progress !== null ? -38 : 0, { size: 74, color: '#fff', stroke: 0, weight: 900 });
  if (progress !== null) { rr(g, -w / 2 + 50, 38, w - 100, 26, 13); g.fillStyle = 'rgba(255,255,255,.18)'; g.fill(); rr(g, -w / 2 + 50, 38, Math.max(26, (w - 100) * progress), 26, 13); g.fillStyle = accent; g.fill(); }
  else if (sub) text(g, sub, 0, 52, { size: 40, color: accent, weight: 800 });
  g.restore();
}
// carte « commentaire » (vote des spectateurs) : { user, text, likes }
export function commentCard(g, o, k = 1) {
  const { user = '', txt = '', likes = '', x = E.W / 2, y = E.H * 0.26, w = 880, h = 190 } = o;
  const s = ease.outBack(k); g.save(); g.translate(x, y); g.scale(s, s); g.rotate(-0.025);
  rr(g, -w / 2, -h / 2, w, h, 26); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 6; g.strokeStyle = '#ffd23f'; g.stroke();
  g.beginPath(); g.arc(-w / 2 + 64, -h / 2 + 62, 34, 0, 7); g.fillStyle = '#c9c4d8'; g.fill();
  text(g, user, -w / 2 + 120, -h / 2 + 44, { size: 28, color: '#8a85a0', align: 'left', weight: 700 });
  text(g, txt, -w / 2 + 120, 6, { size: 44, color: '#14121c', align: 'left', weight: 800 });
  text(g, '♥ ' + likes, w / 2 - 40, h / 2 - 34, { size: 32, color: '#ff2d6f', align: 'right', weight: 800 });
  g.restore();
}
// nombre géant (200, 10000…) qui claque à l'écran
export function bigNumber(g, str, k, o = {}) { const s = ease.outBack(k * 1.4); g.save(); g.translate(E.W / 2, o.y ?? E.H * 0.38); g.scale(s, s); g.rotate(o.rot ?? -0.05); text(g, str, 0, 0, { size: o.size || 300, color: o.color || STYLE.gold, stroke: 26, shadow: 24, weight: 900 }); g.restore(); }
export function flash(g, a) { if (a <= 0) return; g.save(); g.globalAlpha = clamp(a); g.fillStyle = '#fff'; g.fillRect(0, 0, E.W, E.H); g.restore(); }
export function lines(g, t) { g.save(); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 4; for (let i = 0; i < 22; i++) { const a = (i / 22) * Math.PI * 2 + 0.1, r0 = 700 + ((i * 53 + t * 900) % 500), r1 = r0 + 260; g.beginPath(); g.moveTo(E.W / 2 + Math.cos(a) * r0, E.H / 2 + Math.sin(a) * r0 * 1.2); g.lineTo(E.W / 2 + Math.cos(a) * r1, E.H / 2 + Math.sin(a) * r1 * 1.2); g.stroke(); } g.restore(); }  // lignes de vitesse

// ---------- écran de fin ----------
// endCard(g, k, { title:'PARTIE 2 BIENTÔT', question:'Qui a poussé… ?', bg:['#1a2a7a','#06082a'] })
export function endCard(g, k, o = {}) {
  const { title = 'FIN', question = '', bg = ['#7a3fb0', '#e8847a', '#3a2166'], titleSize = 190 } = o;
  const gr = g.createRadialGradient(E.W / 2, E.H * 0.45, 80, E.W / 2, E.H * 0.5, E.H * 0.7); bg.forEach((c, i) => gr.addColorStop(i / (bg.length - 1), c));
  g.fillStyle = gr; g.fillRect(0, 0, E.W, E.H);
  const s = ease.outBack(prog(k, 0, 0.35)), lines_ = title.split('\n');
  g.save(); g.translate(E.W / 2, E.H * 0.42); g.rotate(-0.05); g.scale(s, s);
  lines_.forEach((ln, i) => text(g, ln, 0, (i - (lines_.length - 1) / 2) * titleSize * 1.05, { size: ln.length > 9 ? titleSize * 0.62 : titleSize, color: '#fff', stroke: 22, shadow: 18, weight: 900 }));
  g.restore();
  if (question) text(g, question, E.W / 2, E.H * 0.58, { size: 52, color: STYLE.yellow, stroke: 10, alpha: ease.out(prog(k, 0.35, 0.65)), weight: 900 });
}

// ---------- compteur d'étage empilé (style 2D) : gros chiffre blanc + libellé doré ----------
export function floorStack(g, value, o = {}) {
  const { label = 'ÉTAGE', text: txt = null, y = E.H * 0.17 } = o, v = txt ?? String(Math.round(value));
  text(g, v, E.W / 2, y, { size: v.length > 4 ? 170 : 220, color: '#fff', stroke: 0, shadow: 18, shadowColor: 'rgba(10,0,40,.7)', weight: 900 });
  text(g, label, E.W / 2, y + (v.length > 4 ? 105 : 135), { size: 46, color: '#ffd23f', stroke: 8, strokeColor: '#3a1800', weight: 900 });
}
// ---------- pastille d'argent « +500 € » (pièce dorée + pilule verte) ----------
export function moneyPill(g, str, x, y, k = 1, o = {}) {
  const s = ease.outBack(k), w = measure(g, str, 44) + 118, h = 70; g.save(); g.translate(x, y); g.scale(s, s);
  rr(g, -w / 2, -h / 2, w, h, 35); g.fillStyle = o.bg || '#2e8b3a'; g.fill(); g.lineWidth = 6; g.strokeStyle = '#f7e27a'; g.stroke();
  g.beginPath(); g.arc(-w / 2 + 38, 0, 25, 0, 7); g.fillStyle = '#ffc928'; g.fill(); g.lineWidth = 4; g.strokeStyle = '#b8860b'; g.stroke(); text(g, '€', -w / 2 + 38, 2, { size: 30, color: '#8a5a00', weight: 900 });
  text(g, str, 24, 2, { size: 44, color: '#fff', stroke: 0, weight: 900 }); g.restore();
}
// ---------- téléphone plein écran : en-tête colorée + blocs de texte qui apparaissent ----------
// o = { header:'CENTRE DE LA MALCHANCE', color:'#1aa39a', blocks:[{ text, color, size, from }] }  (from = secondes depuis le début de l'élément)
export function phone(g, o, lt) {
  const { header = '', color = '#1aa39a', blocks = [], x = E.W / 2, y = E.H * 0.42, w = 700, h = 980 } = o, k = ease.outBack(clamp(lt / 0.3));
  g.save(); g.translate(x, y); g.scale(k, k);
  rr(g, -w / 2 - 22, -h / 2 - 22, w + 44, h + 44, 70); g.fillStyle = '#101014'; g.fill();
  rr(g, -w / 2, -h / 2, w, h, 52); g.fillStyle = '#fff'; g.fill(); g.save(); g.clip();
  g.fillStyle = color; g.fillRect(-w / 2, -h / 2, w, 150); text(g, header, 0, -h / 2 + 76, { size: 38, color: '#fff', weight: 900 });
  let yy = -h / 2 + 260;
  for (const b of blocks) { const a = clamp((lt - (b.from ?? 0)) / 0.25); if (a <= 0) { continue; } const sz = b.size || 46, lines_ = String(b.text).split('\n'); lines_.forEach((ln, i) => text(g, ln, 0, yy + i * sz * 1.25, { size: sz, color: b.color || '#222', alpha: a, weight: 900 })); yy += lines_.length * sz * 1.25 + (b.gap ?? 50); }
  g.restore(); g.restore();
}
// ---------- bouton S'ABONNER + compteur ----------
export function subscribe(g, o, k = 1, lt = 0) {
  const { x = E.W / 2, y = E.H * 0.14, amount = [0, 10], label = "S'ABONNER", unit = '€' } = o, s = ease.outBack(k), v = Math.round(amount[0] + (amount[1] - amount[0]) * ease.out(clamp(lt / 1.2)));
  g.save(); g.translate(x, y); g.scale(s, s); rr(g, -190, -42, 380, 84, 42); g.fillStyle = '#ff3d8f'; g.fill(); g.lineWidth = 5; g.strokeStyle = '#fff'; g.stroke();
  text(g, '+ ' + label, 0, 2, { size: 40, color: '#fff', weight: 900 }); rr(g, -90, 70, 180, 64, 14); g.fillStyle = '#12123a'; g.fill(); text(g, `${v} ${unit}`, 0, 104, { size: 38, color: '#6effa0', weight: 900 }); g.restore();
}
// ---------- jauge numérique rouge : « MALCHANCE : 0 % » ----------
export function meter(g, o, v, k = 1) {
  const { label = 'MALCHANCE :', unit = '%', color = '#ff2a2a', x = E.W / 2, y = E.H * 0.3, w = 820, h = 300 } = o, s = ease.outBack(k);
  g.save(); g.translate(x, y); g.scale(s, s); rr(g, -w / 2, -h / 2, w, h, 26); g.fillStyle = '#0a0a10'; g.fill(); g.lineWidth = 6; g.strokeStyle = '#2a2a3a'; g.stroke();
  text(g, label, 0, -78, { size: 52, color: '#fff', weight: 900 }); text(g, `${Math.round(v)} ${unit}`, 0, 12, { size: 130, color, weight: 900 });
  rr(g, -w / 2 + 50, 96, w - 100, 22, 11); g.fillStyle = 'rgba(255,255,255,.15)'; g.fill(); rr(g, -w / 2 + 50, 96, Math.max(22, (w - 100) * clamp(v / 100)), 22, 11); g.fillStyle = color; g.fill(); g.restore();
}
// pluie de billets/confettis 2D (pop de fin)
export function confetti(g, t, n = 70, colors = ['#ffd23f', '#ff4d8f', '#4de0ff', '#7dff6a', '#ffffff']) { g.save(); for (let i = 0; i < n; i++) { const sx = (i * 977) % 1080, sp = 260 + ((i * 131) % 400), y = ((t * sp + i * 173) % (E.H + 200)) - 100, x = sx + Math.sin(t * 3 + i) * 40; g.translate(x, y); g.rotate(t * 4 + i); g.fillStyle = colors[i % colors.length]; g.fillRect(-9, -5, 18, 10); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); } g.restore(); }
