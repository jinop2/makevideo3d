// engine/sets.js — décors prêts à l'emploi. Chaque décor : (T, opts) => { group, anim?(t) }.
// Utilisation dans shots.json : "set": "slum", "setOpts": { "seed": 3 }.   Décor perso : registerSet('nom', fn) dans scenes/sets/*.js
import { registerSet, rng, E } from './core.js';
import * as T from './blocky.js';
const { THREE, box, rbox, cyl, sphere, plane, ground, group, mat, glow, tower, shack, house, goldDome, cloud, tree, lamp, tire, crowd, canvasTex, sign, bus, poodle } = T;

const checker = (a, b, n = 40) => T.canvasTex(128, 128, (g, w, h) => { g.fillStyle = a; g.fillRect(0, 0, w, h); g.fillStyle = b; g.fillRect(0, 0, w / 2, h / 2); g.fillRect(w / 2, h / 2, w / 2, h / 2); }, [n, n]);
const texMat = (tex, o = {}) => new THREE.MeshStandardMaterial({ map: tex, roughness: 0.55, ...o });
// ceinture de tours à l'horizon
function towerRing(o = {}) {
  const { count = 26, rMin = 40, rMax = 140, hMin = 40, hMax = 220, seed = 2, kind = 'glass', kinds = null, spread = Math.PI * 2, a0 = 0, wMax = 12 } = o, r = rng(seed), g = group();
  for (let i = 0; i < count; i++) { const a = a0 + (i / count) * spread + (r() - 0.5) * 0.15, d = rMin + r() * (rMax - rMin), w = 5 + r() * wMax, h = hMin + r() * (hMax - hMin); const t = tower(w, h, w * (0.8 + r() * 0.5), { kind: kinds ? kinds[Math.floor(r() * kinds.length)] : kind, bands: r() < 0.3 ? 3 : 0 }); t.position.set(Math.sin(a) * d, 0, -Math.cos(a) * d); g.add(t); }
  return g;
}

// bidonville au pied des tours : sol brun, cabanes numérotées, pneus, herbe, tours géantes derrière
registerSet('slum', (T_, o = {}) => {
  const r = rng(o.seed || 1), g = group(ground(300, 300, o.ground || '#7b4b2b'));
  const patch = ground(14, 9, '#4aa23a', 0.02); patch.position.set(-9, 0.02, -6); g.add(patch);
  const n = o.shacks ?? 6;
  for (let i = 0; i < n; i++) { const s = shack({ w: 2.6 + r() * 1.4, h: 2 + r() * 0.8, d: 2.4, num: o.numbers === false ? null : i + 1, wood: ['#8a5a34', '#7a4c2a', '#9a6a40'][i % 3] }); s.position.set(-6 + i * 3.6 + (r() - 0.5) * 0.8, 0, -3 - (i % 2) * 2.5); s.rotation.y = (r() - 0.5) * 0.3; g.add(s); }
  for (let i = 0; i < (o.tires ?? 5); i++) { const t = tire(); t.position.set(-8 + r() * 16, 0, 1 + r() * 4); t.rotation.z = r() * 0.4; g.add(t); }
  if (o.fence !== false) for (let i = 0; i < 12; i++) g.add(box(0.12, 1.2, 0.12, '#6a4426', -12 + i * 2.2, 0.6, 5.5));
  g.add(towerRing({ count: 22, rMin: 28, rMax: 110, hMin: 80, hMax: 380, seed: o.seed || 1, spread: Math.PI * 1.1, a0: -Math.PI * 0.55, wMax: 14 }));
  return { group: g };
});

// rue de ville avec maisons basses, lampadaires, arbres, route à tirets
registerSet('street', (T_, o = {}) => {
  const r = rng(o.seed || 4), g = group(ground(300, 300, '#4fae42'));
  g.add(plane(7, 240, '#3a3340', 0, 0.03, -60)); g.children[1].rotation.x = -Math.PI / 2;
  for (let i = 0; i < 24; i++) { const d = box(0.3, 0.02, 2, '#f2c230', 0, 0.06, 6 - i * 4); g.add(d); }
  for (const sx of [-1, 1]) { g.add(box(2.2, 0.12, 240, '#c9c4bd', sx * 4.8, 0.06, -60)); for (let i = 0; i < 12; i++) { const h = house({ w: 3.4 + r() * 1.4, h: 2.4 + r(), d: 3.2, wall: ['#f3efe6', '#f2d9b0', '#d9e8f3', '#f3d5d0'][i % 4], roof: ['#e08a3a', '#c0503a', '#7a4ab0', '#3a7ac0'][i % 4] }); h.position.set(sx * 11, 0, 4 - i * 8); h.rotation.y = sx * -Math.PI / 2; g.add(h); const l = lamp(4.4); l.position.set(sx * 5.6, 0, 2 - i * 8); l.rotation.y = sx > 0 ? Math.PI : 0; g.add(l); if (i % 2) { const t = tree(1.2); t.position.set(sx * 7.5, 0, -2 - i * 8); g.add(t); } } }
  g.add(towerRing({ count: 20, rMin: 90, rMax: 150, hMin: 100, hMax: 300, seed: 3, kind: 'glass' }));
  return { group: g };
});

// champ de gratte-ciel (établissement vertical). opts: hMax, count, kinds
registerSet('skyline', (T_, o = {}) => {
  const g = group(ground(900, 900, o.ground || '#5a8a4a', -0.01));
  g.add(towerRing({ count: o.count ?? 40, rMin: 14, rMax: o.rMax ?? 120, hMin: o.hMin ?? 60, hMax: o.hMax ?? 360, seed: o.seed || 2, kinds: o.kinds || ['glass', 'glass', 'warm', 'pink'], wMax: 12 }));
  if (o.clouds !== false) { const r = rng(9); for (let i = 0; i < (o.cloudCount ?? 14); i++) { const c = cloud(2 + r() * 3, o.cloudColor || '#ffd9ec'); c.position.set((r() - 0.5) * 120, 30 + r() * (o.hMax ?? 360) * 0.8, -20 - r() * 100); g.add(c); } }
  return { group: g };
});

// une tour géante isolée (caméra qui monte). opts: h, kind
registerSet('giantTower', (T_, o = {}) => {
  const h = o.h ?? 400, g = group(ground(900, 900, '#5a8a4a', -0.01));
  g.add(tower(o.w ?? 16, h, o.d ?? 16, { kind: o.kind || 'glass', bands: o.bands ?? 12 }));
  g.add(towerRing({ count: 22, rMin: 26, rMax: 110, hMin: h * 0.2, hMax: h * 0.9, seed: 5, kinds: ['glass', 'warm', 'pink'] }));
  const r = rng(11); for (let i = 0; i < 16; i++) { const c = cloud(2 + r() * 3, '#ffd9ec'); c.position.set((r() - 0.5) * 50, 20 + r() * h, 12 + r() * 20); g.add(c); }
  return { group: g };
});

// plateau de nuages roses avec palais doré et piscine. opts: palace:true
registerSet('cloudDeck', (T_, o = {}) => {
  const r = rng(o.seed || 6), g = group();
  g.add(ground(600, 600, '#f4cfe0', -0.4));
  for (let i = 0; i < 40; i++) { const c = cloud(1.4 + r() * 2, ['#ffd6ea', '#ffe8f2', '#f4b8d8'][i % 3]); c.position.set((r() - 0.5) * 140, -4.5 - r() * 2, -r() * 90 + 12); g.add(c); }
  const dome = goldDome(o.domeR ?? 3.2); dome.position.set(o.domeX ?? -3, 0, -12); g.add(dome);
  g.add(box(26, 1, 26, '#fff4d8', 0, -0.5, -4));
  g.add(box(6, 0.2, 4, '#3fc4e8', 5, 0.05, -2));
  const t = tree(1.2, '#4fb04a'); t.position.set(2, 0, 2); g.add(t);
  g.add(towerRing({ count: 18, rMin: 60, rMax: 130, hMin: 120, hMax: 420, seed: 8, kinds: ['glass', 'pink'], spread: Math.PI * 2 }));
  return { group: g };
});

// intérieur doré : sol damier, tapis rouge, colonnes, écran mural (texte/progression)
registerSet('palace', (T_, o = {}) => {
  const g = group();
  const fl = plane(40, 60, texMat(checker('#f6ecd4', '#e8d8b0', 18)), 0, 0, -10); fl.rotation.x = -Math.PI / 2; g.add(fl);
  g.add(box(3, 0.03, 60, '#c01f2a', 0, 0.02, -10), box(3.5, 0.02, 60, '#f2c230', 0, 0.015, -10));
  g.add(box(40, 14, 0.5, '#f4e4b8', 0, 7, -30), box(40, 0.5, 60, '#f7edd0', 0, 14, -10));
  for (const sx of [-1, 1]) for (let i = 0; i < 6; i++) g.add(cyl(0.5, 0.5, 14, '#f2c230', sx * 9, 7, 4 - i * 8, 16));
  const scr = T.canvasTex(512, 320, (c, W, H) => { c.fillStyle = '#0d2a6a'; c.fillRect(0, 0, W, H); c.fillStyle = '#f2c230'; c.fillRect(0, H * 0.62, W, H * 0.22); c.fillStyle = '#111'; c.font = '900 30px Montserrat'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(o.screenText || 'NOUVEAU PROPRIÉTAIRE', W / 2, H * 0.73); c.fillStyle = '#9fd0ff'; c.fillRect(W / 2 - 70, 36, 140, 140); c.fillStyle = '#f0c59a'; c.fillRect(W / 2 - 50, 60, 100, 100); });
  g.add(plane(14, 8.75, new THREE.MeshBasicMaterial({ map: scr }), 0, 7, -29.7));
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.2, 0.12, 8, 40), mat('#fff3c0', { emissive: '#fff3c0', emissiveIntensity: 0.6 })); ring.rotation.x = Math.PI / 2; ring.position.set(0, 12.5, -10); g.add(ring);
  return { group: g };
});

// salle de contrôle : mur de pastilles colorées lumineuses, pupitre
registerSet('controlRoom', (T_, o = {}) => {
  const g = group(), r = rng(o.seed || 12);
  g.add(ground(60, 60, '#f1e6c8', 0)); g.add(box(40, 16, 0.5, '#2a2230', 0, 8, -14));
  const cols = o.cols ?? 28, rows = o.rows ?? 16, geo = new THREE.SphereGeometry(0.34, 10, 8), mesh = new THREE.InstancedMesh(geo, new THREE.MeshBasicMaterial({ color: '#ffffff' }), cols * rows), m4 = new THREE.Matrix4(), col = new THREE.Color();
  const pal = ['#e53935', '#fdd835', '#43a047', '#1e88e5', '#8e24aa', '#fb8c00', '#ec407a', '#ffffff']; let i = 0;
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) { m4.makeTranslation(-cols * 0.38 + x * 0.78 + 0.3, 1.2 + y * 0.8, -13.6); mesh.setMatrixAt(i, m4); mesh.setColorAt(i, col.set(pal[Math.floor(r() * pal.length)])); i++; }
  g.add(mesh, box(24, 0.9, 3, '#d4a82a', 0, 0.45, -9), box(23, 0.1, 2.6, '#f7e7a8', 0, 0.95, -9));
  for (let k = -3; k <= 3; k++) g.add(cyl(0.12, 0.12, 1.6, '#caa23a', k * 3, 1.7, -9, 10), sphere(0.3, mat(pal[(k + 3) % pal.length]), k * 3, 2.6, -9));
  return { group: g };
});

// ville inondée : eau turquoise, plateformes jaunes carrelées, maisons colorées. opts: platforms
registerSet('waterTown', (T_, o = {}) => {
  const r = rng(o.seed || 3), g = group();
  const water = plane(400, 400, new THREE.MeshStandardMaterial({ color: '#3ec7b4', roughness: 0.2, metalness: 0.15, transparent: true, opacity: 0.92 }), 0, -0.25, -40); water.rotation.x = -Math.PI / 2; g.add(water);
  const tiles = T.canvasTex(64, 64, (c, w, h) => { c.fillStyle = '#f5d78a'; c.fillRect(0, 0, w, h); c.strokeStyle = '#e0b95a'; c.lineWidth = 3; c.strokeRect(0, 0, w, h); }, [6, 6]);
  const col = ['#e8575b', '#4a8fe0', '#8a5fd0', '#f2a03a', '#4fb04a', '#f2eee0'];
  for (let i = 0; i < (o.platforms ?? 14); i++) { const w = 4 + r() * 5, d = 4 + r() * 5, p = group(box(w, 0.5, d, texMat(tiles), 0, 0, 0)); if (i % 2 === 0) { const h = house({ wall: col[i % 6], roof: col[(i + 2) % 6], w: 2.6, d: 2.6 }); h.position.set((r() - 0.5) * (w - 3), 0.25, (r() - 0.5) * (d - 3)); p.add(h); } p.position.set(-10 + (i % 5) * 7 + (r() - 0.5) * 3, 0, 2 - Math.floor(i / 5) * 9); g.add(p); }
  const sign = group(cyl(0.05, 0.05, 2, '#333', 0, 1, 0, 8), box(1.1, 0.9, 0.06, '#f2c230', 0, 2.2, 0)); sign.position.set(-2, 0.25, 4); g.add(sign);
  g.add(towerRing({ count: 14, rMin: 70, rMax: 130, hMin: 60, hMax: 140, seed: 5, kinds: ['warm'], wMax: 20 }));
  return { group: g, anim: t => { water.position.y = -0.25 + Math.sin(t * 1.5) * 0.04; } };
});

// nuit : sol noir, plateforme à grille orange lumineuse, yeux rouges au loin
registerSet('nightGrid', (T_, o = {}) => {
  const g = group(ground(400, 400, '#05050a', -0.3));
  const gridTex = T.canvasTex(128, 128, (c, w, h) => { c.fillStyle = '#1a0a02'; c.fillRect(0, 0, w, h); c.strokeStyle = '#ff7a1a'; c.lineWidth = 5; c.strokeRect(0, 0, w, h); }, [4, 4]);
  for (let i = 0; i < (o.platforms ?? 5); i++) { const p = box(5, 0.4, 5, new THREE.MeshBasicMaterial({ map: gridTex }), -6 + i * 4.5, 0, -2 - (i % 2) * 6); g.add(p); }
  const eyes = group(sphere(0.35, glow('#ff1a1a', 2), -0.7, 0, 0), sphere(0.35, glow('#ff1a1a', 2), 0.7, 0, 0)); eyes.position.set(o.eyeX ?? 6, o.eyeY ?? 3.4, o.eyeZ ?? -30); g.add(eyes);
  return { group: g, anim: t => { eyes.scale.y = 1 - 0.9 * Math.max(0, Math.sin(t * 1.3) ** 40); } };
});

// terrasse piscine : damier lavande, bassin turquoise, palmiers, foule
registerSet('poolDeck', (T_, o = {}) => {
  const g = group(), fl = plane(120, 120, texMat(checker('#efe2ff', '#d8c4f6', 30)), 0, 0, -20); fl.rotation.x = -Math.PI / 2; g.add(fl);
  g.add(box(14, 0.15, 8, '#33c7ee', 3, -0.02, -6), box(14.6, 0.08, 8.6, '#fff', 3, -0.05, -6));
  for (const [x, z] of [[-6, -2], [9, -12], [-8, -14]]) { const p = group(cyl(0.18, 0.25, 4, '#8a5a34', 0, 2, 0, 8)); for (let i = 0; i < 6; i++) { const l = box(0.2, 0.05, 2.4, '#2f9a44', 0, 4, 0); l.rotation.y = (i / 6) * Math.PI * 2; l.rotation.z = 0.35; l.position.set(Math.sin(l.rotation.y) * 0.9, 3.9, Math.cos(l.rotation.y) * 0.9); p.add(l); } p.position.set(x, 0, z); g.add(p); }
  g.add(crowd({ n: o.crowd ?? 40, w: 22, d: 16, x: 0, z: -12, seed: 7, hole: 1.5 }));
  g.add(towerRing({ count: 20, rMin: 60, rMax: 120, hMin: 80, hMax: 280, seed: 6, kinds: ['pink', 'glass'] }));
  return { group: g };
});

// espace : étoiles + lune + plate-forme flottante
registerSet('space', (T_, o = {}) => {
  const g = group(), r = rng(21), pts = [];
  for (let i = 0; i < 700; i++) pts.push((r() - 0.5) * 400, (r() - 0.5) * 300, -60 - r() * 160);
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
  g.add(new THREE.Points(geo, new THREE.PointsMaterial({ color: '#ffffff', size: 0.9, sizeAttenuation: true })));
  g.add(sphere(30, mat('#dfe3ee', { roughness: 1 }), -28, -6, -90));
  const plat = group(cyl(7, 6, 1, '#f4e9cf', 0, -0.5, 0, 28), cyl(2.6, 2.6, 0.5, '#33c7ee', 0, 0.2, -1, 24)); g.add(plat);
  return { group: g, anim: t => { plat.position.y = Math.sin(t * 0.8) * 0.15; } };
});

// fond neutre pour gros plans
registerSet('plain', (T_, o = {}) => ({ group: group(ground(60, 60, o.ground || '#cfc8d8')) }));

// ======== décors adaptés des versions 2D (style « toon 2.5D » : activer config.toon = true) ========

// décharge + cabane « CHEZ MOI » au pied de tours colorées (comme la version 2D, mais en volume)
registerSet('flatCity', (T_, o = {}) => {
  const r = rng(o.seed || 3), g = group(ground(120, 60, o.ground || '#9a5a2a', 0));
  const kinds = ['toonBlue', 'toonPink', 'toonYellow', 'toonPurple', 'toonOrange'];
  for (let i = 0; i < 6; i++) { const t = tower(5 + r() * 3, 30 + r() * 25, 5, { kind: kinds[(i + (o.seed || 0)) % 5], floor: 2.6 }); t.position.set(-16 + i * 6.5, 0, -10 - (i % 2) * 3); g.add(t); }
  const lux = sign(o.luxText || 'LUXE', 3, 1, { bg: '#1a1226', color: '#ffd84a', glow: true }); lux.position.set(6.4, 14, -7.4); g.add(lux);
  const sh = shack({ w: 3.4, h: 2.6, d: 2.6, wood: '#c9873f', roof: '#586070', door: '#6a3b22' }); sh.position.set(o.shackX ?? 2.5, 0, -2); g.add(sh);
  const cm = sign(o.homeText || 'CHEZ MOI', 1.6, 0.5, { bg: '#e9d8a8', color: '#3a2a10', border: '#6a4426' }); cm.position.set((o.shackX ?? 2.5) - 0.9, 3.0, -0.65); g.add(cm);
  for (let i = 0; i < 9; i++) { const k = i % 3; const j = k === 0 ? box(0.8, 1.4, 0.7, '#f1f1f1', 0, 0.7, 0) : k === 1 ? tire(0.4) : sphere(0.45, '#2a2a33', 0, 0.4, 0); j.position.x += -9 + r() * 8 + (i > 4 ? 14 : 0); j.position.z += -3 + r() * 3; g.add(j); }
  for (let i = 0; i < 5; i++) { const c = cloud(1.2 + r(), '#ffffff'); c.position.set(-18 + r() * 36, 22 + r() * 14, -30); g.add(c); }
  return { group: g };
});

// coupe d'immeuble : étages visibles (pièces ouvertes). opts: floors, w, palette
registerSet('cutaway', (T_, o = {}) => {
  const n = o.floors ?? 5, w = o.w ?? 9, fh = 3.2, pal = o.palette || ['#ff8a3a', '#2fb6c9', '#a45ad8', '#ffb83a', '#e8575b'], g = group();
  g.add(ground(80, 40, '#2a2a40', -0.01));
  for (let i = 0; i < n; i++) {
    const c = pal[i % pal.length], y = i * fh;
    g.add(box(w, fh - 0.15, 0.3, c, 0, y + fh / 2, -2), box(w, 0.2, 5, '#f3efe6', 0, y + 0.1, 0.3), box(0.3, fh, 5, '#3a3350', -w / 2, y + fh / 2, 0.3), box(0.3, fh, 5, '#3a3350', w / 2, y + fh / 2, 0.3));
    for (const sx of [-2.4, 2.4]) { g.add(box(1.6, 1.4, 0.1, '#bfe6ff', sx, y + 1.8, -1.83), box(0.2, 1.5, 0.12, '#ffd1ef', sx - 0.9, y + 1.8, -1.75), box(0.2, 1.5, 0.12, '#ffd1ef', sx + 0.9, y + 1.8, -1.75)); }
    g.add(box(1.8, 0.6, 1.2, ['#7a4ab0', '#2a6fd0', '#e8575b'][i % 3], (i % 2 ? -1 : 1) * 1.2, y + 0.5, -0.8));
  }
  g.add(box(w + 0.8, 0.5, 5.6, '#3a3350', 0, n * fh + 0.25, 0.3));
  return { group: g, spawn: [0, 0, 0] };
});

// île flottante des milliardaires + planètes, fusée, étoiles
registerSet('island', (T_, o = {}) => {
  const r = rng(5), g = group(), pts = [];
  for (let i = 0; i < 500; i++) pts.push((r() - 0.5) * 160, (r() - 0.5) * 120 + 10, -40 - r() * 80);
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3)); g.add(new THREE.Points(geo, new THREE.PointsMaterial({ color: '#fff', size: 0.7 })));
  const rock = new THREE.Mesh(new THREE.ConeGeometry(5.5, 5, 12), mat('#9a6a3a')); rock.rotation.x = Math.PI; rock.position.y = -2.5; rock.castShadow = true;
  const isl = group(cyl(5.6, 5.5, 0.6, '#f5c030', 0, 0.1, 0, 24), rock);
  const palm = group(cyl(0.15, 0.2, 3, '#8a5a34', 0, 1.5, 0, 8)); for (let i = 0; i < 6; i++) { const l = box(0.25, 0.06, 2.2, '#2fa044', 0, 3, 0); l.rotation.y = (i / 6) * 6.28; l.rotation.z = 0.35; l.position.set(Math.sin(l.rotation.y) * 0.9, 2.95, Math.cos(l.rotation.y) * 0.9); palm.add(l); }
  palm.position.set(-3, 0.4, 0); isl.add(palm); const hs = house({ wall: '#fff6d8', roof: '#ffc21f', w: 3, d: 3 }); hs.position.set(2.2, 0.4, -1); isl.add(hs); g.add(isl);
  const planet = group(sphere(2.2, '#ff9a3a', 0, 0, 0)); const ring = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.14, 8, 40), mat('#ffd9a0')); ring.rotation.x = 1.2; planet.add(ring); planet.position.set(9, 8, -22); g.add(planet);
  g.add(sphere(1.4, '#d9d6f0', -9, 10, -26));
  return { group: g, anim: t => { isl.position.y = Math.sin(t * 0.9) * 0.25; planet.rotation.y = t * 0.2; } };
});

// salon de luxe : damier noir et blanc, fenêtre à rideaux sur la ville, lustre, caniche rose sur coussin
registerSet('luxRoom', (T_, o = {}) => {
  const g = group(), fl = plane(30, 30, texMat(checker('#ffffff', '#1a1a3a', 14)), 0, 0, -4); fl.rotation.x = -Math.PI / 2; g.add(fl);
  g.add(box(14, 9, 0.3, '#f7ecc4', 0, 4.5, -8));
  const city = canvasTex(256, 256, (c, W, H) => { c.fillStyle = '#2a1a5a'; c.fillRect(0, 0, W, H); ['#ff3fa4', '#2c6fe0', '#ffc21f', '#7a3fd0'].forEach((col, i) => { c.fillStyle = col; c.fillRect(20 + i * 58, 70 + (i % 2) * 50, 46, 190); c.fillStyle = '#ffe58a'; for (let y = 0; y < 5; y++) c.fillRect(30 + i * 58, 90 + (i % 2) * 50 + y * 30, 10, 10), c.fillRect(48 + i * 58, 90 + (i % 2) * 50 + y * 30, 10, 10); }); });
  g.add(plane(5, 5, new THREE.MeshBasicMaterial({ map: city }), 0, 4.8, -7.8), box(5.4, 0.25, 0.3, '#f2c230', 0, 7.4, -7.7), box(5.4, 0.25, 0.3, '#f2c230', 0, 2.2, -7.7));
  g.add(box(1.0, 5.6, 0.3, '#c01f7a', -3.2, 4.8, -7.6), box(1.0, 5.6, 0.3, '#c01f7a', 3.2, 4.8, -7.6));
  const ch = group(cyl(0.05, 0.05, 1.2, '#f2c230', 0, 0.6, 0, 6), cyl(1.0, 0.7, 0.3, '#f2c230', 0, 0, 0, 14)); for (let i = 0; i < 6; i++) ch.add(sphere(0.12, glow('#fff3b0', 1.2), Math.cos(i) * 0.9, -0.2, Math.sin(i) * 0.9)); ch.position.set(0, 8.3, -3); g.add(ch);
  const cu = cyl(1.2, 1.2, 0.35, '#e0457f', 0, 0.18, 0, 20), dog = poodle({ color: o.dogColor || '#ffb3d1' }); dog.position.set(0, 0.35, 0); const pet = group(cu, dog); pet.position.set(0, 0, -2); g.add(pet);
  return { group: g, anim: t => { dog.rotation.z = Math.sin(t * 2) * 0.03; } };
});

// fond « sunburst » violet/rose pour les écrans d'appel à l'action (héros au premier plan)
registerSet('burst', (T_, o = {}) => {
  const tex = canvasTex(512, 512, (c, W, H) => { const n = 18; for (let i = 0; i < n; i++) { c.fillStyle = i % 2 ? (o.c1 || '#c93ad8') : (o.c2 || '#e65cc4'); c.beginPath(); c.moveTo(W / 2, H / 2); c.arc(W / 2, H / 2, W, (i / n) * 6.2832, ((i + 1) / n) * 6.2832); c.closePath(); c.fill(); } });
  const bg = plane(60, 60, new THREE.MeshBasicMaterial({ map: tex }), 0, 3, -8); const g = group(bg, ground(30, 30, '#6a1aa0', 0));
  return { group: g, anim: t => { bg.rotation.z = t * 0.08; } };
});

// ======== décors urbains lumineux (style « rue de ville », blocs) ========
function shopFront(w, h, color, awn, text) { const g = group(rbox(w, h, 4, color, 0, h / 2, 0, 0.05)); g.add(box(w * 0.7, h * 0.35, 0.08, '#cfeaff', 0, h * 0.4, 2.02), box(w, 0.35, 1.1, awn, 0, h * 0.62, 2.4)); if (text) { const s = sign(text, w * 0.8, 0.7, { bg: '#1a1226', color: '#ffd84a', glow: true }); s.position.set(0, h * 0.82, 2.05); g.add(s); } return g; }
registerSet('avenue', (T_, o = {}) => {
  const r = rng(o.seed || 8), g = group(ground(300, 300, '#59b34a'));
  const road = plane(10, 260, '#3a3a44', 0, 0.03, -60); road.rotation.x = -Math.PI / 2; g.add(road);
  for (let i = 0; i < 20; i++) g.add(box(0.25, 0.02, 2, '#f4f4f4', 0, 0.06, 6 - i * 5));
  const cols = ['#9fd8c4', '#f4d7a8', '#c6b4f0', '#f4b4c4', '#a8d0f4', '#ffe28a'], aw = ['#e8575b', '#2c6fe0', '#ffc21f', '#7a3fd0'];
  for (const sx of [-1, 1]) { g.add(box(5, 0.14, 260, '#d6d6de', sx * 7.5, 0.07, -60)); for (let i = 0; i < 12; i++) { const sf = shopFront(6 + r() * 2, 6 + r() * 5, cols[(i + (sx > 0 ? 3 : 0)) % 6], aw[i % 4], o.shops && i % 3 === 0 ? o.shops[(i / 3) % o.shops.length | 0] : null); sf.position.set(sx * 13.5, 0, 4 - i * 8); sf.rotation.y = sx > 0 ? -Math.PI / 2 : Math.PI / 2; g.add(sf); if (i % 2) { const t = tree(1.3); t.position.set(sx * 6, 0, -2 - i * 8); g.add(t); } } }
  if (o.bus) { const b = bus({ label: o.busLabel || 'LIGNE 13' }); b.position.set(o.busX ?? 2.5, 0, o.busZ ?? -6); g.add(b); }
  g.add(towerRing({ count: 22, rMin: 100, rMax: 160, hMin: 60, hMax: 220, seed: 4, kinds: ['glass', 'warm'] }));
  return { group: g };
});
// façade d'un grand bâtiment avec enseigne : opts { text, color }
registerSet('facade', (T_, o = {}) => {
  const g = group(ground(200, 200, '#d6d6de')), c = o.wall || '#f2f5f7';
  g.add(plane(80, 60, '#6fbf5a', 0, -0.02, 30)); g.children[1].rotation.x = -Math.PI / 2;
  g.add(rbox(16, 9, 8, c, 0, 4.5, -8, 0.1), box(16.2, 0.4, 8.2, o.color || '#0d8a80', 0, 9.2, -8), box(5, 3.6, 0.2, '#bfe6ff', 0, 1.8, -3.95));
  const s = sign(o.text || 'CENTRE', 12, 1.6, { bg: '#ffffff', color: o.color || '#0d8a80' }); s.position.set(0, 7.4, -3.88); g.add(s);
  for (const x of [-5.5, 5.5]) g.add(box(2.6, 2.4, 0.15, '#bfe6ff', x, 3.4, -3.95), box(2.6, 2.4, 0.15, '#bfe6ff', x, 6.2, -3.95));
  for (const x of [-9, 9]) { const t = tree(1.4); t.position.set(x, 0, -1); g.add(t); }
  g.add(towerRing({ count: 16, rMin: 80, rMax: 140, hMin: 60, hMax: 200, seed: 9, kinds: ['glass', 'warm'] }));
  return { group: g };
});
// chambre : parquet, lit, bibliothèque
registerSet('bedroom', (T_, o = {}) => {
  const g = group(), fl = plane(16, 16, '#c98a4a', 0, 0, 0); fl.rotation.x = -Math.PI / 2; g.add(fl, box(16, 7, 0.3, o.wall || '#e8d2c0', 0, 3.5, -4), box(0.3, 7, 16, o.wall || '#e8d2c0', -6, 3.5, 3));
  g.add(rbox(4.2, 0.7, 2.4, '#8a5a34', -2.6, 0.35, -2.6, 0.05), rbox(3.8, 0.35, 2.1, '#3b5a9a', -2.6, 0.85, -2.6, 0.1), rbox(1.2, 0.3, 0.8, '#ffffff', -4.0, 1.1, -2.9, 0.1));
  g.add(box(2.4, 3.2, 0.7, '#8a5a34', 3.2, 1.6, -3.5)); ['#e8575b', '#2c6fe0', '#ffc21f', '#4fb04a', '#7a3fd0'].forEach((c, i) => g.add(box(0.28, 0.7, 0.4, c, 2.4 + i * 0.4, 1.0, -3.2), box(0.28, 0.7, 0.4, c, 2.5 + i * 0.4, 2.1, -3.2)));
  return { group: g };
});
