// engine/core.js — runtime commun. Canevas logique 9:16 = 1080 x 1920 (le player met à l'échelle).
export const E = { W: 1080, H: 1920, PX: 1, fps: 30, cfg: {}, words: [], shots: [], cast: {}, outW: 1080, outH: 1920 };

// ---------- maths / temps ----------
export const clamp = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x);
export const lerp = (a, b, k) => a + (b - a) * k;
export const prog = (t, a, b) => clamp((t - a) / (b - a));
export const ease = {
  linear: x => clamp(x),
  in: x => (x = clamp(x)) ** 3,
  out: x => 1 - (1 - clamp(x)) ** 3,
  inOut: x => ((x = clamp(x)) < 0.5 ? 4 * x ** 3 : 1 - (-2 * x + 2) ** 3 / 2),
  sine: x => -(Math.cos(Math.PI * clamp(x)) - 1) / 2,
  outBack: x => { x = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2; },
  outElastic: x => { x = clamp(x); return x === 0 || x === 1 ? x : 2 ** (-10 * x) * Math.sin((x * 10 - 0.75) * (2 * Math.PI) / 3) + 1; },
};
export function mixVal(a, b, k) {
  if (typeof a === 'number') return lerp(a, b, k);
  if (Array.isArray(a)) return a.map((v, i) => mixVal(v, b[i], k));
  const o = {}; for (const kk in a) o[kk] = typeof a[kk] === 'number' || Array.isArray(a[kk]) ? mixVal(a[kk], b[kk] ?? a[kk], k) : (k < 0.5 ? a[kk] : b[kk] ?? a[kk]); return o;
}
// images clés : key(t, [[0, 1], [2, 1.2], [4, 1]], ease.inOut) -> nombre | tableau | objet de nombres
export function key(t, frames, fn = ease.inOut) {
  if (t <= frames[0][0]) return frames[0][1];
  for (let i = 1; i < frames.length; i++) {
    const [t1, v1] = frames[i];
    if (t <= t1) { const [t0, v0] = frames[i - 1]; return mixVal(v0, v1, (frames[i][2] || fn)((t - t0) / (t1 - t0))); }
  }
  return frames[frames.length - 1][1];
}
export function rng(seed = 1) { return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const hash = (n) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
export function noise(x, seed = 0) { const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f); return lerp(hash(i + seed * 57), hash(i + 1 + seed * 57), u) * 2 - 1; }
export const shake = (t, amp = 0.05, freq = 9, seed = 3) => [noise(t * freq, seed) * amp, noise(t * freq, seed + 9) * amp, noise(t * freq, seed + 21) * amp];

// instant (secondes globales) où un mot est prononcé : wordTime('riches', 5) -> 6.82 (null si absent)
const nw = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w']/g, '');
export function wordTime(match, after = 0) {
  const m = nw(match);
  const w = E.words.find(w => w.start >= after - 0.05 && nw(w.word).startsWith(m));
  return w ? w.start : null;
}

// ---------- couleurs ----------
export function hex(c) { const h = c.replace('#', ''); const n = parseInt(h.length === 3 ? [...h].map(x => x + x).join('') : h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
export const alpha = (c, a) => { const [r, g, b] = hex(c); return `rgba(${r},${g},${b},${a})`; };

// ---------- texte 2D ----------
export const FONTS = { cap: 'Montserrat' };
export function text(g, str, x, y, o = {}) {
  const { size = 48, font = FONTS.cap, weight = 900, color = '#fff', align = 'center', base = 'middle', stroke = 0, strokeColor = '#000', shadow = 0, shadowColor = 'rgba(0,0,0,.55)', alpha: a = 1, spacing = 0 } = o;
  g.save(); g.globalAlpha *= a; g.font = `${weight} ${size}px "${font}"`; g.textAlign = align; g.textBaseline = base;
  if ('letterSpacing' in g) g.letterSpacing = `${spacing}px`;
  if (shadow) { g.shadowColor = shadowColor; g.shadowBlur = shadow; g.shadowOffsetY = shadow * 0.35; }
  if (stroke) { g.lineJoin = 'round'; g.miterLimit = 2; g.lineWidth = stroke; g.strokeStyle = strokeColor; g.strokeText(str, x, y); g.shadowColor = 'transparent'; }
  g.fillStyle = color; g.fillText(str, x, y); g.restore();
}
export function measure(g, str, size, font = FONTS.cap, weight = 900) { g.save(); g.font = `${weight} ${size}px "${font}"`; const w = g.measureText(str).width; g.restore(); return w; }
export function rr(g, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

// ---------- registres ----------
const SHOTS = {}, SETS = {};
// registerShot('s012', { init(T, info), draw(s, t, info, T), overlay?(g, t, info, s) })  -> plan personnalisé en code
export function registerShot(id, def) { SHOTS[id] = { kind: '3d', ...def }; }
export const getShot = id => SHOTS[id];
// registerSet('monDecor', (T, opts) => ({ group, anim?(t), spawn?:[x,y,z] }))  -> décor réutilisable par les plans JSON
export function registerSet(name, fn) { SETS[name] = fn; }
export const getSet = name => SETS[name];
export const allSets = () => Object.keys(SETS);
