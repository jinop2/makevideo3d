---
name: make-your-day-shorts
description: "Crée des vidéos TikTok/Reels/Shorts verticales (35 à 110 s) en 3D à blocs animée par code, à partir d'une voix off fournie par l'utilisateur : monde extrême et vertical (riches tout en haut, pauvres tout en bas), héros à la première personne, sous-titres jaunes mot par mot, badge PARTIE N, jauge ÉTAGE, cliffhanger et écran de fin. Le décor et la direction artistique varient selon le thème (4 familles : fantasy, city, toon = 2D adapté en 3D, neon). Skill 100 % autonome (moteur Three.js + Chromium + ffmpeg inclus dans kit/, aucune image ou vidéo IA). Aide à trouver l'histoire (3 pitchs) et écrit le texte de la voix off à enregistrer, puis transcrit l'audio, découpe en plans, rend la vidéo et mixe musique + SFX. Déclenche sur : 'Make Your Day', histoire à parties TikTok, ville divisée riches pauvres, monde 3D blocky/Roblox, 'je t'envoie la voix off', 'aide-moi à trouver l'histoire', texte de voix off à enregistrer, sous-titres un mot à l'écran, cliffhanger partie 2, animation rendue par code."
metadata:
  version: "1.0.0"
  langue: fr
  sources: "analyse de 6 vidéos de référence (1080x1920, 30 fps, 59 à 108 s)"
---

# Make Your Day Shorts : histoires 3D verticales, rendues par code

L'utilisateur fournit (ou fait écrire) une **voix off**, tu fournis **l'histoire, le découpage et l'animation 3D rendue par code**. Aucune image ni vidéo générée par IA : tout est dessiné par le moteur du dossier `kit/` (Three.js + Chromium headless + ffmpeg + Python).

Le style est fixe, les histoires sont **toujours nouvelles** : ne jamais recopier les personnages, noms ou scènes des vidéos de référence (`assets/reference-frames/`, planches 1 image / 3 s). Regarde-les avant de concevoir un plan.

## Règles d'or
1. **La voix off est intouchable** une fois enregistrée : ne jamais réécrire, ajouter, retirer ou réordonner un mot. Chaque plan illustre ce qui est dit à ce moment précis.
2. **Idée choc dans les 3 premières secondes** (contraste extrême ou règle absurde du monde).
3. **Un mot à l'écran à la fois**, synchronisé sur la voix, du début à la fin.
4. **Monde lisible d'un coup d'œil** : code couleur riche/pauvre, échelle, chiffres qui explosent (jauge ÉTAGE).
5. **Toujours finir sur un crochet** : question, twist, ou « PARTIE 2 BIENTÔT » / « FIN, tu veux une partie 3 ? ».
6. **Cohérence** : un personnage = une silhouette, une couleur signature, une tenue fixe.
7. **Regarder avant de livrer** : planche-contact relue (`--sheet`) avant de lancer le rendu final et avant d'annoncer que c'est fini.
8. **Le décor suit le thème** : choisir la famille et les décors selon l'histoire ; une direction artistique différente d'une vidéo à l'autre est voulue.
9. **Honnêteté sur les limites** : le rendu du kit est plus simple que celui des vidéos de référence (matières, eau, profondeur de champ). Le dire si c'est pertinent et montrer des plans d'essai avant de produire toute une vidéo.

## Workflow

### Étape 0 : Intake (une seule fois, questions groupées, valeurs par défaut sinon)
- **Famille visuelle selon le thème** (`visual-grammar.md`, section 1) : `fantasy` (tours géantes, ciel pastel), `city` (rue lumineuse, histoire du quotidien), `toon` (2D adapté en 3D, contours épais, héros chibi) ou `neon` (approchée seulement). Le décor change selon le thème et à chaque idée : ne pas rester sur un seul lieu.
- **Durée** : le format court de **35 à 45 s** (~105 à 125 mots) est valide et conseillé pour une idée simple ; 80 à 100 s pour une histoire à parties. Série en plusieurs parties : oui/non.
- L'utilisateur a-t-il déjà son histoire ? Sinon : étape 1B.
- Machine : GPU ? (le rendu est lent sans GPU, voir `references/install.md`).

### Étape 1 : L'histoire et la voix off
- **1A. Il envoie l'histoire ou la voix off** : la lire deux fois, la mapper sur les 6 temps de `references/narrative-formula.md`, signaler en 5 lignes max ce qui manque (hook, règle du monde, cliffhanger) et proposer des correctifs **sans toucher à son texte** sans son accord.
- **1B. Il faut la créer** : proposer **3 pitchs** d'une ligne (monde, règle choc, héros, secret, cliffhanger) ; après son choix, écrire la **fiche de série** puis le **texte de la voix off** au format d'export (`narrative-formula.md`, sections 5 à 7). Il l'enregistre (ElevenLabs ou autre) et envoie l'audio.

### Étape 2 : Installer et créer le projet
1. Installer le kit s'il n'est pas déjà installé (`references/install.md`), `python tools/doctor.py`.
2. `python tools/new_project.py --name <slug> --voice <audio> --script <texte.txt> --part 1 --sky sunset`
3. Remplir `story/cast.json` (personnages, tenue, couleur signature) selon la fiche de série.

### Étape 3 : Timestamps
`python tools/transcribe.py --project projects/<slug> --script input/script.txt --lang fr` (Whisper). Sans Whisper : SRT + `tools/srt_to_words.py`. Relire `timeline/transcript.txt` (`references/audio-and-timing.md`).

### Étape 4 : Découpage plan par plan
`python tools/beats.py --project projects/<slug> --endcard "PARTIE 2\nBIENTÔT|Question ?"` crée un brouillon de `story/shots.json`. Puis **remplir chaque plan** (décor, caméra, acteurs, HUD, interface, SFX) selon `references/visual-grammar.md` (rythme, types de plans) et `references/engine-api.md` (champs JSON). Résumer le plan en 5 à 10 lignes à l'utilisateur et continuer sauf objection.

### Étape 5 : Contrôle visuel
`node render.mjs --project projects/<slug> --sheet --scale 0.35` puis ouvrir `build/sheets/sheet_01.png`. Corriger : caméra dans un bâtiment/nuage, texte illisible, plan qui ne correspond pas aux mots, 3 plans identiques d'affilée, `MISSING`/`ERREUR` dans la planche. Boucler jusqu'à propre. Pour les plans d'action, un aperçu vidéo `--from/--to`.

### Étape 6 : Rendu final et son
1. `node render.mjs --project projects/<slug>` (long : annoncer la durée estimée, lancer en tâche de fond).
2. Musique et SFX : `story/shots.json` (`music`, `sfx`, `amb`) puis `python audio/mix.py --project projects/<slug>` -> `out/<titre>.mp4`.
3. Livrer le fichier final et le texte de la légende/CTA (question de fin).

### Étape 7 : Série
Pour la partie suivante : réutiliser `cast.json`, la fiche de série et le même ciel/HUD ; ouvrir par un rappel de 1 à 2 phrases ; incrémenter `config.part`.

## Fichiers
- `references/style-analysis.md` : mesures et observations des 6 vidéos (deux familles visuelles).
- `references/narrative-formula.md` : structure narrative, écriture de la voix off, fiche de série, format d'export du texte, pitchs.
- `references/visual-grammar.md` : les 4 familles de décor, adaptation d'un décor 2D en 3D, types de plans, rythme, sous-titres, HUD, écrans de fin, checklist QC.
- `references/engine-api.md` : schéma `shots.json`, décors, acteurs, caméras, interface, plans en code, commandes.
- `references/audio-and-timing.md` : voix, timestamps, musique, SFX, mixage.
- `references/install.md` : installation du kit, test, vitesses mesurées.
- `kit/` : moteur autonome (`engine/`, `render.mjs`, `tools/`, `audio/`, `examples/demo/` et `examples/demo-toon/`).
